var objCordovaWebView;
var fs                  = require('fs');
var request             = require('request');
var AdmZip              = require('adm-zip');
var md5File             = require('md5-file');
var checksum            = require('checksum');
var Q                   = require('Q');
var EJstorage           = require('electron-json-storage-sync');
var mailToID            = "mailTo:" + SUPPORT_EMAIL_ID;
var pkgChkSumNew        = "";
var varChkOpnPkg        = 0;
var NewHomeScreenOpened = 1;
var ckhKBSame           = 0;
var chkSumCounter       = 0;
var firstChecker        = 0;
isLoggedIn              = 1;
var appResolution       = "";
var out, dl;
var os                  = require("os");
var networkType         = os.networkInterfaces();
var getMacId            = "";
var kbCall              = 0;
var addInform           = "";
var {ipcRenderer, remote} = require('electron');  
var SUPPORT_EMAIL_ID      = "Friends@dronamobile.com";

// var open                = require('open');
// var openUpdater = function (urlLocation) {
//     open(urlLocation);
// }

for (i = 0; i < 3; i++) {
    var theNameOfObjectMwahahahaha = Object.keys(networkType)[i];
    if (networkType[theNameOfObjectMwahahahaha] != undefined) {
        var objectKaData = networkType[theNameOfObjectMwahahahaha][0].mac;
        if (objectKaData == "00:00:00:00:00:00")
            continue;
        else{
            getMacId = objectKaData;
            break;
        }
    }
    else
        getMacId = "00:00:00:00:00:00";
}

DEVICE_ID = getMacId;

var _logoutAPI = function(userId) {
    var deferred = Q.defer();
    var reqData = {
        device_id: DEVICE_ID,
        uid: userId
    };
    var fnSuccess = function() {
        deferred.resolve();
    }
    var fnError = function() {
        deferred.resolve();
    }
    fnAjaxRequest(API_BASE_URL + "useraccount.aspx", "POST", {}, reqData, fnSuccess, fnError);
    return deferred.promise;
}

var _logout = function(userInitiated) {
    if (userInitiated) {
        //Make Logout API request
        //var user = localStorage.getItem('userData');
        var user = getJsonData('userData');
        removeAllJsonData();
        var objUser = JSON.parse(user);
        var user_id = objUser.uid;
        //Delete All JSON Data
        startPageBlock();
        _logoutAPI(user_id).then(function() {
            stopPageBlock();
            localStorage.clear();
            window.location.href = 'login.html';
        });
    } else {
        _logoutAPI(user_id).then(function() {
            removeAllJsonData();
            stopPageBlock();
            localStorage.clear();
            window.location.href = 'login.html';
        });
    }
}

var authToken = function() {
    // var accessToken = localStorage.getItem("accessToken");
    var accessToken = getJsonData('accessToken');
    if (accessToken == null || accessToken == undefined || accessToken.length === 0) {
        _logout();
    }
}

var startPageBlock = function(message) {
    // $.blockUI({
    $.blockUI({
        message: '<p></p>',
        css: {
            border: 'none',
            padding: '20px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: 0.5,
            color: '#fff'
        }
    });
};

var startDivBlock = function($e, message) {
    message = message || 'please wait...';
    $e.block({
        message: '<p>' + message + '</p>',
        css: {
            border: 'none',
            padding: '20px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: 0.5,
            color: '#fff'
        }
    });
};

var updatePageBlockMessage = function(message, doAppend) {
    var msg = '<p>' + message + '</p>';
    if (doAppend) {
        $('.blockUI.blockMsg.blockPage').append(msg);
    } else {
        $('.blockUI.blockMsg.blockPage').html(msg);
    }

}

var stopDivBlock = function($e) {
    $e.unblock();
};

var stopPageBlock = function() {
    $.unblockUI();
};

var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function(e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            } else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        }
        return t
    },
    decode: function(e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t);
        return t
    },
    _utf8_encode: function(e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        }
        return t
    },
    _utf8_decode: function(e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        }
        return t
    }
}

var fnAjaxRequest = function(ajaxURL, ajaxReqMethod, ajaxReqHeader, ajaxReqData, onSucess, onError, contentType) {
    $.ajax({

        type: ajaxReqMethod,
        url: ajaxURL,
        data: ajaxReqData,
        headers: ajaxReqHeader,
        success: onSucess,
        error: onError,
        contentType: contentType || 'application/x-www-form-urlencoded'
    });
};

function onError(jqXHR, textStatus, errorThrown) {
    //Show error message        
    if (jqXHR.status === 500) {
        alert("Oops...Something went wrong!");
    }
}

function fnDronaError(errorCode, reqJson) {
    if (errorCode == 0) {
        swal('Server error!');
    } else if (errorCode == 1) {
        swal('Invalid request');
    } else if (errorCode == 2) {} else if (errorCode == 3) {
        afterSessionTimeOut();
    }
}

//fn: render handlebar-template to html
//inputParam: template_id, data
//return: html

var fnHandlebarTemplate = function(templateId, data) {
    var x = "#" + templateId;
    var source = $("#" + templateId).html();
    var template = Handlebars.compile(source);
    var html = template(data);
    return html;
}


//function to format dates

var formatDate = function(originalDate) {
    if (window.moment && moment(originalDate).isValid()) {
        var nowDtTime = moment.utc();
        var feedDateTime = moment.utc(originalDate, 'YYYY-MM-DD HH-mm-ss');

        var diffSec = nowDtTime.diff(feedDateTime, 'seconds');
        var retrunVal = '';

        if (diffSec < 1) {
            return "just now";
        }

        if (diffSec < 60) {
            if (diffSec === 1) {
                return diffSec + ' sec ago';
            } else {
                return diffSec + ' secs ago';
            }
        }


        //Difference greater then 60 secs, convert it to minutes
        var diffMin = Math.floor(diffSec / 60);
        if (diffMin < 60) {
            if (diffMin === 1) {
                return diffMin + ' min ago';
            } else {
                return diffMin + ' mins ago';
            }
        }

        //Difference is greater than 60 minutes
        var diffHour = Math.floor(diffMin / 60);
        if (diffHour < 24) {
            if (diffHour === 1)
                return diffHour + ' hour ago';
            else
                return diffHour + ' hours ago';
        }

        //Difference is greater than 24 hours, convert it to days
        var diffDay = Math.floor(diffHour / 24);
        if (diffDay < 8) {
            if (diffDay === 1) {
                return diffDay + ' day ago';
            } else {
                return diffDay + ' days ago';
            }
        }

        //Difference is more than 30 days, send date as it is
        return feedDateTime.local().format('DD MMM');
    } else
        return '';
};

var fireworks = function(elementId, width, height) {

    function Particle(x, y, radius) {
        this.init(x, y, radius);
    }

    Particle.prototype = {

        init: function(x, y, radius) {

            this.alive = true;

            this.radius = radius || 10;
            this.wander = 0.15;
            this.theta = random(TWO_PI);
            this.drag = 0.92;
            this.color = '#fff';

            this.x = x || 0.0;
            this.y = y || 0.0;

            this.vx = 0.0;
            this.vy = 0.0;
        },

        move: function() {

            this.x += this.vx;
            this.y += this.vy;

            this.vx *= this.drag;
            this.vy *= this.drag;

            this.theta += random(-0.5, 0.5) * this.wander;
            this.vx += sin(this.theta) * 0.1;
            this.vy += cos(this.theta) * 0.1;

            this.radius *= 0.96;
            this.alive = this.radius > 0.5;
        },

        draw: function(ctx) {

            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, TWO_PI);
            ctx.fillStyle = this.color;
            ctx.fill();
        }
    };

    // ----------------------------------------
    // Example
    // ----------------------------------------

    var MAX_PARTICLES = 280;
    var COLOURS = ['#69D2E7', '#A7DBD8', '#E0E4CC', '#F38630', '#FA6900', '#FF4E50', '#F9D423'];

    var particles = [];
    var pool = [];

    var demo = Sketch.create({
        container: document.getElementById(elementId),
        fullscreen: false,
        width: width,
        height: height
    });

    demo.setup = function() {

        // Set off some initial particles.
        var i, x, y;

        for (i = 0; i < 20; i++) {
            x = (demo.width * 0.5) + random(-100, 100);
            y = (demo.height * 0.5) + random(-100, 100);
            demo.spawn(x, y);
        }
    };

    demo.spawn = function(x, y) {

        if (particles.length >= MAX_PARTICLES)
            pool.push(particles.shift());

        particle = pool.length ? pool.pop() : new Particle();
        particle.init(x, y, random(5, 40));

        particle.wander = random(0.5, 2.0);
        particle.color = random(COLOURS);
        particle.drag = random(0.9, 0.99);

        theta = random(TWO_PI);
        force = random(2, 8);

        particle.vx = sin(theta) * force;
        particle.vy = cos(theta) * force;

        particles.push(particle);
    }

    demo.update = function() {

        var i, particle;

        for (i = particles.length - 1; i >= 0; i--) {

            particle = particles[i];

            if (particle.alive) particle.move();
            else pool.push(particles.splice(i, 1)[0]);
        }
    };

    demo.draw = function() {

        demo.globalCompositeOperation = 'lighter';

        for (var i = particles.length - 1; i >= 0; i--) {
            particles[i].draw(demo);
        }
    };

    demo.mousemove = function() {

        var particle, theta, force, touch, max, i, j, n;

        for (i = 0, n = demo.touches.length; i < n; i++) {

            touch = demo.touches[i], max = random(1, 4);
            for (j = 0; j < max; j++) demo.spawn(touch.x, touch.y);
        }
    };

}

/* Adding My Code for now as the code does not seem to work with the Diffrent file hope this works */

var postDownlaod = function(file_url, targetPath, pkgChkSum) {
    var chker;
    checksum.file(destLocation + "/" + appVersion + ".zip", function(err, pkgChkSumNew12) {
        pkgChkSumNew = pkgChkSumNew12;
        toDownloadOrNot();
    });

    function toDownloadOrNot() {
        if (pkgChkSumNew == pkgChkSum) {
            chker = 1;
            chkSumCounter++;
            if (chkSumCounter < 3) {
                if (chker == 1) {
                    // let RNCryptor = require('jscryptor');
                    // let preBase   = fs.readFileSync(destLocation + "/" + appVersion + ".zip");
                    // let decrypted = RNCryptor.Decrypt(preBase, DECRYPTION_KEY);
                    // fs.writeFileSync(destLocation + "/" + appVersion + ".zip", decrypted);
                    let args = [];
                    args[0] = destLocation;
                    args[1] = appVersion;
                    args[2] = DECRYPTION_KEY;
                    let success = ipcRenderer.sendSync('sync',args);
                    // ipcRenderer.send('async', "ExitAppMwahahahaha");
                    if(success === 1)
                        openfile(targetPath);
                } else {
                    downloadFile(file_url, targetPath, pkgChkSum);
                }
            } else {
                let RNCryptor = require('jscryptor');
                let preBase   = fs.readFileSync(destLocation + "/" + appVersion + ".zip");
                let decrypted = RNCryptor.Decrypt(preBase, DECRYPTION_KEY);
                fs.writeFileSync(destLocation + "/" + appVersion + ".zip", decrypted);
                decrypted = null;
                RNCryptor = null;
                openfile(targetPath);
            }
        }
    }
}

var downloadFile = function (file_url, targetPath, pkgChkSum, appName, iconLink, appSize) {
    //Save variable to know progress
    if (!fs.existsSync(destLocation + "/" + appVersion + "/" + "INDEX.HTML")) {
        /* Hide views and show the app downloading */
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
        $('#create-home-screen').removeClass('hide');
        $('.progress-bar').css('width', '0%');
        $('#set-app-name').html(appName);
        $('#app-image').css('background-image', "url(" + iconLink + ")");

        var received_bytes = 0;
        var total_bytes = 0;
        out = fs.createWriteStream(targetPath);
        var req = request({
            method: 'GET',
            uri: file_url
        });

        var showProgress = function (received, total) {
            var percentage = (received * 100) / total;
            $('.progress-bar').css('width', percentage + "%");
        }

        //fs.createWriteStream(testing);
        req.pipe(out);

        req.on('response', function (data) {
            //Change the total bytes value to get progress later.
            total_bytes = parseInt(data.headers['content-length']);
        });

        req.on('data', function (chunk) {
            //Update the received bytes
            received_bytes += chunk.length;
            showProgress(received_bytes, total_bytes);
        });

        req.on('end', function () {
            postDownlaod(file_url, targetPath, pkgChkSum);
        });
    } else {
        if (varChkOpnPkg == 1)
            loadFileFinal();
        else { }
    }
};

// Eventhandler for file input. 
var openfile = function(fileName) {

    var zip = new AdmZip(fileName);
    var zipEntries = zip.getEntries();
    var dfd = jQuery.Deferred();

    $.when(zip.extractAllTo(destLocation + "/" + appVersion, true)).then(
        //$.when(extract(fileName,{dir:destLocation + "/" + appVersion}, function (err) {})).then(
        function(status) {
            if (varChkOpnPkg == 1)
                loadFileFinal();
        });
    return dfd.promise();
};

var closeApp = function() {
    $('body').on('click', '.closeTopTeamgumGumitBar', function() {
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
        $('#dvContentListContainer').addClass('hide');
        $('.aw-modal-body').css('padding-bottom','0');
        $('#webview1').remove();
        timeSpentInApp(Math.round(+new Date() / 1000));
        clickedActionButton = 0;
        globalPluginVersion = "";
    });
};

var loadFileFinal = function () {
    var closediv = document.createElement('div');
    var appHeight = $('html').css('height');
    var appWidth = $('html').css('width');
    var webview = document.createElement('webview');
    $(webview).attr("disablewebsecurity", "");
    var appRes = appResolution;

    if (appRes == undefined || appRes == null || appRes.min_width == null || appRes.max_width == null){
        appRes = []
        appRes.min_width = appRes.max_width = 0;
    }
    if (parseInt(appRes.min_width) <= parseInt(appWidth)) {
        if (parseInt(appRes.max_width) > 0)
            appWidth = appRes.max_width;

        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
        $(closediv).attr('id', 'webview1');
        $(closediv).css('width', appWidth);
        $(closediv).css('height', appHeight);

        document.body.appendChild(closediv);
        var webviewAppender = document.getElementById('webview1');

        $(webview).css('width', appWidth);
        $(webview).css('height', "calc(" + appHeight + " - 2.5rem)");
        var userData = JSON.parse(getJsonData('userData'));
        webview.src = destLocation + "/" + appVersion + "/index.html?dm_uid="+userData.uid;
        webview.preload = __dirname + "/preload.js" // +" , "+ __dirname+"/myJS/DronaAppPage.js";
        webview.useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"
        webview.addEventListener('dom-ready', () => {
            webview.openDevTools();
        });
        webviewAppender.appendChild(webview);

        $('#create-home-screen').addClass('hide');
        $('#webview1').append('<div style="width:100%; position: fixed; bottom: 0; z-index: 9999;">' +
            '<div class="the-close-bar" style="width:100%">' +
            '<div class="closeTopTeamgumGumitBar closewala" style="width:100%; text-align:center;font-weight: 100; height:2.5rem; cursor:pointer; color:#fff;">CLOSE</div>' +
            '</div></div>');

        timeStampStart = Math.round(+new Date() / 1000);
        closeApp();
    } else {
        swal('', appRes.min_width_msg, 'error');
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
        $('#create-home-screen').removeClass('hide');
    }
};

var timeSpentInApp = function(timeStampEnd) {
    var onSuccess = function(resp) {};
    var onError = function() {};

    var timeDifference = timeStampEnd - timeStampStart;
    if (timeDifference < 0)
        timeDifference = 0;

    // var userData = JSON.parse(localStorage.getItem('userData'));
    var userData = JSON.parse(getJsonData('userData'));
    var user_id = userData.uid;
    var postData = JSON.stringify({
        "data": {
            "time_spent": timeDifference,
            "ab_id": clickedActionButton,
            "uid": user_id,
            "plugin_version": globalPluginVersion
        },
        "type": "actionButton"
    });
    fnAjaxRequest(API_BASE_URL + 'timespent.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: postData
    }, onSuccess, onError);

};

var timeSpentInMainApp = function(finalTimeStampEnd) {

    var onSuccess = function(resp) {};
    var onError = function() {};


    var timeDifference = timeStampEnd - timeStampMainAppStart;
    if (timeDifference < 0)
        timeDifference = 0;

    // var userData = JSON.parse(localStorage.getItem('userData'));
    var userData = JSON.parse(getJsonData('userData'));
    var user_id = userData.uid;
    var postData = JSON.stringify({
        "type": "app",
        "data": {
            "uid": user_id,
            "time_spent": timeDifference
        }
    });

    fnAjaxRequest(API_BASE_URL + 'timespent.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: postData
    }, onSuccess, onError);
};

var callFromMain = function() {
    if (clickedActionButton != "")
        timeSpentInApp(Math.round(+new Date() / 1000));
};

var callToSendTimeSpent = function() {
    timeSpentInMainApp(Math.round(+new Date() / 1000));
};

var callOnReopen = function() {
    if (clickedActionButton != "")
        timeStampStart = Math.round(+new Date() / 1000);
};

var callOnReopenMainApp = function() {
    timeStampMainAppStart = Math.round(+new Date() / 1000);
    kbCall = 0;
    window.objDronaHQ.fetchKnowledgeBase();
    callCheckForUpdate();
};

var afterSessionTimeOut = function (getFunctioncall) {
    var onSuccess = function (data) {
        data = JSON.parse(data);
        respResponse = parseInt(data.resp, 10)
        var setparams = function () {
            var deferred = Q.defer();
            if (respResponse === 0) {
                swal({
                    title: "Oops",
                    text: "Something Went Wrong, Please Try Loging in again",
                    closeOnConfirm: true
                },
                    function () {
                        _logout();
                    });
                deferred.reject();
            } else {
                localStorage.setItem("accessToken", data.access_token.toString());
                localStorage.setItem("refreshToken", data.refresh_token.toString());
                setJsonData("accessToken", data.access_token);
                setJsonData("refreshToken", data.refresh_token);
                base64String = Base64.encode(data.access_token);
                switch(getFunctioncall){
                    case 'knowledgeBase':
                        window.objDronaHQ.fetchKnowledgeBase();
                        break;
                }
                deferred.resolve();
            }
            return deferred.promise;
        }
        setparams().then(function (data) {
            if(kbCall == 0){
                window.objDronaHQ.fetchKnowledgeBase();
                kbCall = 1;
            }
        });
    }
    var refreshToken = getJsonData("refreshToken");
    if (refreshToken != null && refreshToken != undefined && refreshToken != "") {
        /* Proper way of ajaxrequest lol worked hard for it haha */
        var ajaxReqData = {
            device_id: getMacId,
            refresh_token: refreshToken
        }
        ajaxReqData = JSON.stringify(ajaxReqData);

        var updatedBase64String = Base64.encode(OAUTH_CLIENT_ID + ":" + OAUTH_CLIENT_SECRET);
        fnAjaxRequest(API_BASE_URL + 'refreshtoken.aspx', 'POST', {
                Authorization: 'Basic ' + updatedBase64String
            },
            ajaxReqData, onSuccess, onError);
    } else {
        _logout();
    }
};

var getAppMeta = function() {
    var os = require('os');
    var deferred = Q.defer();
    var userData = getJsonData("userData");
    var networkType = os.networkInterfaces();
    var getMacId = "";
    var userId;
    userData = JSON.parse(userData);
    userId = userData.uid;

    for (i = 0; i < 3; i++) {
        var theNameOfObjectMwahahahaha = Object.keys(networkType)[i];
        if (networkType[theNameOfObjectMwahahahaha] != undefined) {
            var objectKaData = networkType[theNameOfObjectMwahahahaha][0].mac;
            if (objectKaData == "00:00:00:00:00:00")
                continue;
            else
                getMacId = objectKaData;
                break;
        }
        else
            getMacId = "00:00:00:00:00:00";
    }

    var ajaxReqData = {
        "uid" : userId,
        "device_id" : getMacId
    }
    ajaxReqData = JSON.stringify(ajaxReqData);
    // ajaxReqData = JSON.stringify(ajaxReqData);
    // ajaxReqData = "{}";

    var onSuccess = function(data) {
        data = JSON.parse(data)
        if (!(data.resp)) {
            localStorage.setItem('appMeta', JSON.stringify(data));
            setJsonData('appMeta', JSON.stringify(data));
        } else if (data.resp == 3) {
            var errorMessage;
            if (data.lock_msg == undefined || data.lock_msg == "")
                errorMessage = "Your account has been locked. Please upgrade your license or contact admin or mail us at " + SUPPORT_EMAIL_ID;
            else
                errorMessage = data.lock_msg;
            swal({
                title: "",
                text: errorMessage,
                type: "success",
                confirmButtonColor: "#28bc6a",
                confirmButtonText: "Okay!",
                closeOnConfirm: true
            }, function() {
                _logout();
            });
        }
        deferred.resolve();
    }

    let oldGetAppMeta = getJsonData('appMeta');
    let accessToken = getJsonData('accessToken');
    base64String = Base64.encode(accessToken);
    if (oldGetAppMeta != undefined) {
        onSuccess(oldGetAppMeta);
    } else {
        fnAjaxRequest(API_BASE_URL + 'getappmeta.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, ajaxReqData
        , onSuccess, onError);
    }

    return deferred.promise;
};

var callCheckForUpdate = function() {
    var os = require('os');
    var freeMemory = os.freemem();
    var deferred = Q.defer();
    var userData = getJsonData("userData");
    var osVersion = os.release();
    var deviceName = os.hostname();
    var memoryValue = process.memoryUsage();
    var memoryTotal = memoryValue.rss + memoryValue.heapTotal + memoryValue.heapUsed + memoryValue.external;
    var networkType = os.networkInterfaces();
    var getMacId = "";
    userData = JSON.parse(userData);

    for (i = 0; i < 3; i++) {
        var theNameOfObjectMwahahahaha = Object.keys(networkType)[i];
        if (networkType[theNameOfObjectMwahahahaha] != undefined) {
            var objectKaData = networkType[theNameOfObjectMwahahahaha][0].mac;
            if (objectKaData == "00:00:00:00:00:00")
                continue;
            else
                getMacId = objectKaData;
            break;
        }
        else
            getMacId = "00:00:00:00:00:00";
    }

    var onSuccess = function(data) {
        data = JSON.parse(data);

        switch (data.resp) {
            case "0":
                // swal('',
                //     'Server mein gadbad',
                //     'error');
                break;
            case "1":
                swal('',
                    '',
                    'error');
                break;
            case "3":
                swal({
                    html:true,
                    title: "",
                    text: "Invalid User Kindly Login Again",
                    type: "Error",
                    confirmButtonColor: "#28bc6a",
                    confirmButtonText: "Okay!",
                    closeOnConfirm: true
                }, function() {
                    _logout();
                });
                break;
            case "4":
                console.log("Nice all is updated");
                break;
        }

        if (!data.resp) {
            var open = require('open');

            $('body').on('click', '.open-download-update-link', function () {
                let {shell} = require('electron');
                shell.openExternal(data.download_link);
            });
            
            if (data.upgrade_type.toLowerCase() == "force") {
                swal({
                    html:true,
                    title: 'Update',
                    text:  "There is an upgrade available for " + APP_NAME + ". Please upgrade app for your better experience" +
                        "<br><a href='#' class='open-download-update-link'>Click Here</a> for downloading the Update",
                    showCancelButton: false,
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            }
            else {
                swal({
                    html:true,
                    title: 'Update',
                    text:  "There is an upgrade available for " + APP_NAME + ". Please upgrade app for your better experience" +
                        "<br><a href='#'  class='open-download-update-link');>Click Here</a> for downloading the Update",
                    showCancelButton: false,
                    showConfirmButton: false,
                    allowOutsideClick: true
                });
            }
        }

        deferred.resolve();
    }

    var ajaxReqData = {
        "uid": userData.uid,
        "device_type": DEVICE_TYPE,
        "device_id": getMacId,
        "device_name": deviceName,
        "app_name": APP_NAME,
        "app_version": APP_NAME,
        "os_version": osVersion,
        "model": "DEV_MODEL",
        "free_memory": freeMemory,
        "used_by_app": memoryTotal,
        "is_rooted": 0
    };

    fnAjaxRequest(API_BASE_URL + 'checkforupdate.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: ajaxReqData
    }, onSuccess, onError);

    return deferred.promise;
};

/* 
    JSON STORAGE DECLARATION FOR ELECTRON JSON STORAGE
   MOST OF THEM ARE SELF EXPLANATORY SO USE THEM :) 
*/

var setJsonData = function(keyName, jsonData) {
    var successData = EJstorage.set(keyName, jsonData);
    if (successData.status)
        return successData
};

var getAllJsonKeys = function() {
    var successData = EJstorage.keys();
    return successData.data;
};

var getJsonData = function(keyName) {
    var successData = EJstorage.get(keyName);
    return successData.data;
};

var removeJsonData = function(keyName) {
    var successData = EJstorage.remove(keyName);
    return successData;
};

var removeAllJsonData = function() {
    var successData = EJstorage.clear();
    return successData;
};

var toSetHomeScreenOrNot = function(aBData) {

    var yeHaiABArray = aBData;

    for (var i = 0; i < yeHaiABArray.length; i++) {

        if (yeHaiABArray[i].plugin_version.open_code != null && yeHaiABArray[i].plugin_version.open_code != "") {
            NewHomeScreenOpened = 1;
            var appId = yeHaiABArray[i].ab_id;
            var pkgLink = yeHaiABArray[i].action_url;
            var pkgChkSum = yeHaiABArray[i].plugin_version.package_checksum;
            var iconLink = yeHaiABArray[i].image_url;
            var appName = yeHaiABArray[i].title;
            var appSize = yeHaiABArray[i].plugin_version.package_size;
            appVersion = yeHaiABArray[i].plugin_version.version_code;

            if (!fs.existsSync(__dirname + "/piz")) {
                fs.mkdirSync(__dirname + "/piz");
            }

            destLocation = __dirname + "/piz/" + appId;
            var fileLocation = __dirname + "/piz/" + appId + "/" + appVersion + ".zip";

            if (!fs.existsSync(destLocation)) {
                fs.mkdirSync(destLocation);
            }

            if (!fs.existsSync(destLocation + "/" + appVersion)) {
                fs.mkdirSync(destLocation + "/" + appVersion);
            }
            varChkOpnPkg = 0;

            downloadFile(pkgLink, destLocation + "/" + appVersion + ".zip", pkgChkSum, appName, iconLink, appSize);
        }
    }
};

// var enableAutoLauncher = function () {
//     let AutoLaunch = require('auto-launch');
//     let dronaHQAutoLauncher = new AutoLaunch({
//         name: 'DronaHQ',
//         path: 'D:/DronaHQ - Electron/DronaHQ-win32-x64/DronaHQ.exe',
//     });
//     dronaHQAutoLauncher.enable();
//     //dronaHQAutoLauncher.disable();
//     dronaHQAutoLauncher.isEnabled()
//         .then(function (isEnabled) {
//             if (isEnabled) {
//                 return;
//             }
//             dronaHQAutoLauncher.enable();
//         })
//         .catch(function (err) {
//             // handle error
//             alert("Auto Launch Does Not Seem To Work");
//         });
// }

// enableAutoLauncher();

$('body').on('click', '.closewalaCMS', function () {
    $('#dvModalHeader, #dvContentContainer, .hideTheCloseBar, #dvContentListContainer').addClass('hide');
    //$('#dvIframeContainer').css('height', 'calc(100% + 2.5rem)');
    $('#dvIframeContainer').removeClass('hide');
    $('.aw-modal-body').css('padding-bottom', '0');
    $('.aw-modal-body').css('height','100%');
    $('.aw-modal').css('padding-bottom','0');
    //height: calc(100% - 55px); */
});


/* END OF JSON STORAGE DECLARATION */

/* Added code just to make sure that we dont get logged out if we are getting into the application after a long time :D */
/* Finally end of my code */

//call on landing page after login

/*
 
var result ="" ;
var ifFound = 0;
regedit.list(linkToFindApps,function(err,result1){
    result = result1;
});
var allResult = result[Object.keys(result)[0]].keys;
allResult.forEach(function (lol){
    if(lol == "appname.exe")
        ifFound = 1;
});

if (ifFound == 1){
    getNameOfTheApp = "chrome.exe";
    finalAppPath = linkToFindApps + "//" + getNameOfTheApp;
    regedit.list(finalAppPath,function(entry){
        result = entry.data;
    });
    thePath = result.values.Path.value;
    var shell = require('electron').shell;
    var isSuccessful = shell.openItem()
}

var list objests array

*/

var DronaAppLanding = function() {
    

    var objUser = {};
    var storeUser, storePlugin, storeNoti;
    var user, u_uid;

    if (getJsonData('accessToken') != null) {
        user = getJsonData('userData');
        u_uid = JSON.parse(user);

        var user_id = u_uid.uid;
        var accessToken = getJsonData('accessToken');

        base64String = Base64.encode(accessToken);
    }


    var _initUser = function() {
        // var userData = localStorage.getItem('userData');
        // var accessToken = localStorage.getItem('accessToken');

        var userData = getJsonData('userData');
        var accessToken = getJsonData('accessToken');
        if (!userData) {
            return;
        }
        objUser = JSON.parse(userData);

        //Populate the store
        storeUser.save({
            key: 'uinfo',
            data: objUser
        });

        storeUser.save({
            key: 'u-token',
            data: accessToken
        })
    };

    //fn: load app list
    //inputParam: {uid:user_id}
    var _loadAppList = function() {
        var deferred          = Q.defer();
        var allJsonKeys       = getAllJsonKeys();
        var knowledgebaseData = "knowledgeBaseData";

        $('#appListLoader').removeClass('hide');

        function onSuccess(respData) {
            $('#appListLoader').addClass('hide');
            timeStampMainAppStart = Math.round(+new Date() / 1000);
            var data = JSON.parse(respData);
            //var data = respData;
            if (data.knowledge_base) {
                //var checkIfStoredSuccessful =  setJsonData("knowledgeBaseData",JSON.stringify(data.knowledge_base));
                let oldKnowledgeBaseData  = getJsonData('knowledgeBaseDataOld');
                let oldKBAB               = "";
                let oldKBCat              = "";
                let respDataParsed        = JSON.parse(respData);
                let newKBAB               = respDataParsed.knowledge_base.action_button || null;
                let newKBCat              = respDataParsed.knowledge_base.category || null;
                if(oldKnowledgeBaseData   != undefined){
                    oldKnowledgeBaseData  = JSON.parse(oldKnowledgeBaseData);
                    oldKBAB               = oldKnowledgeBaseData.knowledge_base.action_button;
                    oldKBCat              = oldKnowledgeBaseData.knowledge_base.category || null;
                }
                if (oldKBAB != newKBAB || oldKBCat != newKBCat) {

                    var arrActionBtn = data.knowledge_base.action_button;
                    //Store all plugin action buttons for later retrival
                    var arrPluginApp = _.filter(arrActionBtn, {
                        sub_type: 'plugin'
                    });
                    var arrPluginAfterSorted = _.filter(arrActionBtn, {
                        is_hidden: 0
                    });
                    /* Filter native view */
                    // _.remove(arrPluginAfterSorted,{
                    //     action:"nativeview"
                    // });
                    // /* Filter native view from Folder */
                    // for (let j = 0; j < arrPluginAfterSorted.length; j++) {
                    //     let test = arrPluginAfterSorted[j].folder_data.icons;
                    //     let iPopFromArray = [];
                    //     for (let i = 0; test.length > i; i++) {
                    //         if (test[i].data.action == "nativeview")
                    //             iPopFromArray.push(i);
                    //     };
                    //     iPopFromArray.forEach(function(deLocation){
                    //         test.pop(deLocation);
                    //     });
                    //     arrPluginAfterSorted[j].folder_data.icons = test;
                    // }
                    _.forEach(arrPluginApp, function (objApp) {
                        storePlugin.save({
                            key: 'app-' + objApp.ab_id,
                            data: objApp
                        });
                    });

                    data.knowledge_base.action_button = arrPluginAfterSorted;
                    arrPluginAfterSorted = JSON.stringify(data);

                    /* Store the updated and receiived KB for verification */
                    setJsonData("knowledgeBaseData", arrPluginAfterSorted);
                    setJsonData("knowledgeBaseDataOld", respData);

                    /* If the KB has updated for the first time dont fire */
                    if (firstChecker != 0)
                        objCordovaWebView.fireDocumentEvent('dronahq.app.kbupdate', "");
                }
                firstChecker = 1;

                toSetHomeScreenOrNot(data.knowledge_base.action_button);

                deferred.resolve(data);

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0)
                    swal('Oops!', 'Server error!', 'error');
                else if (errorCode == 1)
                    swal('Oops!', 'Invalid request', 'error');
                else if (errorCode == 3)
                    afterSessionTimeOut('knowledgeBase');
                deferred.reject(data);
            }
        }

        var postData = JSON.stringify({
            uid: user_id
        });

        //#TODO : Need to uncomment this code before publish.
        /* This is the code to verify that the knowledgeBase is same or not and then accordingly call it */
        var valPresent = jQuery.inArray(knowledgebaseData, allJsonKeys)
        if (valPresent > -1) {
            var knowledgebase = getJsonData("knowledgeBaseData");
            ckhKBSame = 1;
            if (firstChecker == 0)
                onSuccess(knowledgebase);

            fnAjaxRequest(API_BASE_URL + 'getknowledgebase.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
            getAppMeta();
        } else {
            fnAjaxRequest(API_BASE_URL + 'getknowledgebase.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
            getAppMeta();
        }
        return deferred.promise;
    }

    var _loadInboxData = function(_maxInboxId, _maxInboxResult, searchText, filterType) {
        var deferred = Q.defer();
        var allJsonKeys = getAllJsonKeys();
        var getInbox = "inboxData";
        $('#appListLoader').removeClass('hide');

        function onSuccess(respdata) {
            setJsonData('inboxData', respdata);
            var data = JSON.parse(respdata);

            if (data.moduleInbox) {

                var arrAppNoti = _.filter(data.moduleInbox, {
                    content_json: {
                        sub_type: 'app_noti'
                    }
                });

                _.forEach(arrAppNoti, function(objModule) {
                    var objNotiData = objModule.content_json.noti_data;
                    var appData = objNotiData.app_data;

                    if (appData) {
                        
                        storeNoti.save({
                            key: 'noti-' + objNotiData.noti_id,
                            data: JSON.parse(appData)
                        });
                    }
                });

                // Reset unread inbox badge count
                storeUser.save({
                    key: 'unread-inbox',
                    data: 0
                });

                deferred.resolve(data);

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    deferred.reject(data);
                } else if (errorCode == 1) {
                    deferred.reject(data);
                } else if (errorCode == 2) {
                    deferred.reject(data);
                } else if (errorCode == 3) {
                    afterSessionTimeOut();
                }
            }
        }

        var postData = JSON.stringify({
            uid: user_id,
            inbox_id: _maxInboxId,
            inbox_count: _maxInboxResult,
            search_text: searchText,
            filter_type: filterType
        });
        var valPresent = jQuery.inArray(getInbox, allJsonKeys)
        if (valPresent > -1) {
            var getInbox = getJsonData(getInbox);
            onSuccess(getInbox);
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {

                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }
        return deferred.promise;
    }

    var loadMore = true;
    var pageSize = 10;
    var startIndex = 0;
    //fn: load category detail
    //pagination support
    //inputParam: catId, click
    //catId: category id
    //click: bool [set true while click on category icon; false on load more]
    var _loadCatDetail = function(catId, click) {

        //var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');
        $('#content_loader').removeClass('hide');

        //$('#uListCategoryDetail').append($vatLoaderTemp);

        function onSuccess(respData) {

            var data = JSON.parse(respData);
            if (data.module_content) {
                var tempData = {
                    module_content: data.module_content
                }
                var html = fnHandlebarTemplate('template-cat-detail-v2', data);
                //$('#frameWebview').remove();

                if (startIndex == 0) {
                    $('#dvContentListContainer').empty();
                }

                startIndex = startIndex + data.module_content.length;

                if ((startIndex == data.total_result_count) || (data.module_content.length < pageSize)) {
                    loadMore = false;
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                //$('#uListCategoryDetail').append(HTML);
                $('#dvContentListContainer').append(html);

                $('#loaderIframeWebView').addClass('hide');
            } else if (data.resp) {
                $('#loaderIframeWebView').addClass('hide');

                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    //$('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    afterSessionTimeOut();
                }
            }
        }

        var postData = JSON.stringify({
            type: "shortContentJson",
            data: {
                cat_id: catId,
                uid: user_id,
                start_index: startIndex,
                expected_size: pageSize,
                filter_type: '',
                search_text: ''
            }
        });

        fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var _loadCatContent = function(cId, cType) {
        var elapsed;
        var start = new Date();
        $('#content_loader').removeClass('hide');

        function onSuccess(respData) {

            var data = JSON.parse(respData);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    swal('Sorry', ' Content no longer available!');
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            } else {
                var tempData;
                switch (cType) {
                    case 'ig':
                        tempData = {
                            image_array: data.image_url,
                            type: cType,
                            title: data.title
                        };
                        break;
                    case 'v':
                        tempData = {
                            type: cType,
                            thumbnail_url: data.thumbnail_url.high_thumb,
                            title: data.title,
                            cid: data.cid,
                            comment_count: data.comment_count,
                            length: data.length,
                            modify_date: data.modify_date,
                            author: data.author,
                            description: data.description
                        };
                        break;
                    case 'audio':
                        tempData = {
                            title: data.title,
                            length: data.length,
                            type: cType,
                            comment_count: data.comment_count,
                            audio_url: data.audio_url
                        }
                        break;
                    case 'article':
                        tempData = data;
                        break;
                    case 'pdf':
                        tempData = data;
                        var pdf_url = '/pdfrenderer.ashx?url=' + data.pdf_url.pdf_url + '&cid=' + cId;
                        pdf_url = encodeURIComponent(pdf_url);
                        tempData = {
                            yoData: pdf_url,
                            type: cType,
                            cid: cId,
                            pdf_size: data.pdf_url.pdf_size,
                            title: data.title,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            description: data.description,
                            has_third_screen: true
                        };
                        break;
                    case 'p':
                        tempData = {
                            description: data.description,
                            yoData: data.slide_data,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            has_third_screen: true,
                            length: data.slide_data.length
                        };
                        break;
                    case 'q':
                        tempData = {
                            description: data.description,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            yoData: data.quiz_data.question,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            length: data.quiz_data.question.length,
                            has_third_screen: true
                        }
                        break;
                    case 'e':
                        break;
                    case 'text':
                        tempData = data;
                        break;
                    case 's':
                        tempData = {
                            description: data.description,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            yoData: data.survey_data.question,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            length: data.survey_data.question.length,
                            has_third_screen: true
                        }
                        break;
                    case 'form':
                        tempData = {
                            form_url: data.form_url + '&dm_uid=' + user_id
                        }
                        break;
                    case 'embed':
                        tempData = {
                            title: data.title,
                            type: cType,
                            embed_data: data.embed_data
                        };
                        break;
                    case 'n':
                        tempData = data;
                        break;
                }
            }

            if (cType === 'form') {
                //There is not meta with this content
                //directly open the form_url in webview

                $('#dvContentContainer').addClass('hide');
                $('#dvIframeContainer').removeClass('hide');

                $('#frameWebview').attr('src', tempData.form_url);

                console.log(tempData.form_url);
                $modal.find('.aw-modal-header').removeClass('webview');
                return;
            }

            //Handle app notification
            if (cType === 'text') {
                if (tempData.sub_type === 'app_noti') {
                    //This is a app notification
                    var appId = tempData.noti_data.app_id;
                    var notiId = tempData.noti_data.noti_id;

                    storePlugin.get('app-' + appId, function (data) {
                        if (data == null || data == undefined) {
                            swal({
                                    title: "",
                                    text: "App is no longer available.",
                                    closeOnConfirm: true
                                },
                                function () {
                                    $('#dvModalHeader').addClass('hide');
                                    $('#dvWebView , #confirmCloseModal , .aw-modal-overlay , #dvIframeContainer').removeClass('hide');
                                    $('#loaderIframeWebView').addClass('hide');
                                    $('#webview1').remove();
                                    $('.aw-modal-body').css('padding-bottom','0');
                                });
                        } else {
                            var objApp = data.data;
                            var appAction = objApp.action.toLowerCase();
                            var appUrl = '';
                            if (appAction === 'webview') {
                                appUrl = objApp.action_url;
                            } else if (appAction === 'localview' || appAction == 'internalview') {
                                if (objApp.sub_type === 'plugin') {
                                    appUrl = objApp.plugin_version.web_url;
                                }
                            }

                            if (appUrl) {
                                $('#dvContentContainer').addClass('hide');
                                $('#dvIframeContainer').removeClass('hide');

                                appUrl = _fnAppendUserId(appUrl, notiId);
                                _webViewPopup(appUrl, true, false, appId);

                                //If close button to be hidden, hide the header
                                if (objApp.sub_type === 'plugin') {
                                    if (objApp.plugin_version.hide_close_button) {
                                        //Hide the headr
                                        $('#dvModalHeader').addClass('hide');

                                        //Remove padding from
                                        $('#dvModalHeader').next().css('padding-bottom', '0');
                                    }
                                }
                                return;
                            } else {
                                swal("This app is not available on the web!");
                            }
                        }
                    });
                    return;
                }
            }

            $modal.find('.aw-modal-header').removeClass('webview');

            $('#dvContentContainer').removeClass('hide');
            $('.aw-modal-body').css('padding-bottom','25px');
            $('.aw-modal-body').append('<div style="width:100%; position: fixed; bottom: 0; z-index: 9999;" class="hideTheCloseBar">' +
            '<div class="the-close-bar" style="width:100%">' +
            '<div class="closeTopTeamgumGumitBar closewalaCMS" style="width:100%; text-align:center;font-weight: 100; height:2.5rem; color: #fff; cursor:pointer;">CLOSE</div>' +
            '</div></div>');
            $('#dvIframeContainer').addClass('hide');
            $('#loaderIframeWebView').addClass('hide');
            $('.aw-modal').css('padding-bottom','0');

            var HTML = fnHandlebarTemplate('tmpl-cms-content', tempData);

            $('#dvContentMeta').html('');
            $('#dvContentMeta').html(HTML);
            //$('#dvContentMeta').removeClass('hidden');
            //$('#dvContentMeta').addClass('fdivisible');
            if (cType == 'pdf') {
                //$("#iframePdfViewer").attr('src', 'web/viewer.html?file=' + pdf_url);

            } else if (cType == 'audio') {

                var playerInstance = jwplayer("audiodiv");
                playerInstance.setup({

                    file: data.audio_url.audio_url,

                    // URL to the image that should be shown before the video is started
                    image: "",
                    title: data.title,
                    width: '100%',
                    height: '50px',
                });
            } else if (cType == 'v') {
                var fnVideoStreamSuccess = function(respData) {
                    var streamData = JSON.parse(respData);

                    if (streamData.resp) {
                        var errorCode = streamData.resp;
                        if (errorCode == 0) {
                            swal('Oops!', 'Server error!', 'error');
                        } else if (errorCode == 1) {
                            swal('Oops!', 'Invalid request', 'error');
                        } else if (errorCode == 2) {
                            swal('Sorry', ' Content no longer available!');
                        } else if (errorCode == 3) {
                            // swal({
                            //     title: "Oops",
                            //     text: "Session Expired",
                            //     closeOnConfirm: true
                            // });
                            afterSessionTimeOut();
                        }
                    } else {
                        var rtmpUrl = streamData.rtsp_stream_url.replace('rtsp://', 'rtmp://');
                        var playerInstance = jwplayer("videodiv");
                        playerInstance.setup({
                            file: rtmpUrl,
                            // URL to the image that should be shown before the video is started
                            image: data.thumbnail_url.high_thumb,
                            title: data.title,
                            width: '100%',
                            aspectratio: '16:9'
                        });
                    }
                }
                var postData1 = JSON.stringify({
                    type: "GetStream",
                    data: {
                        uid: user_id,
                        cid: cId
                    }
                });
                fnAjaxRequest(API_BASE_URL + 'getstreamurl.aspx', 'POST', {
                    Authorization: 'Bearer ' + base64String
                }, {
                    abc: postData1
                }, fnVideoStreamSuccess, onError);
            }

            elapsed = new Date() - start;
        }

        if (cType == 'v') {
            var postData = JSON.stringify({
                type: "longContentJson",
                data: {
                    cid: cId,
                    uid: user_id
                }
            });
            fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            var postData = JSON.stringify({
                type: "longContentJson",
                data: {
                    cid: cId,
                    uid: user_id
                }
            });
            fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }

        return elapsed;
    }

    //inbox/notification

    var _maxInboxId = 0;
    var _maxInboxResult = 15;
    var _loadInbox = function() {
        var allJsonKeys = getAllJsonKeys();
        var catContent = "catContent";
        $('#inbox').addClass('active');
        $('#bookmark').removeClass('active');
        var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');

        $('#spPaneName').text('Inbox');

        $('#uListCategoryDetail').append($vatLoaderTemp);

        function onSuccess(respdata) {
            setJsonData('catContent', respdata);
            var data = JSON.parse(respdata);

            if (data.moduleInbox) {
                if (_maxInboxId === 0) {
                    $('#dvCategContentList').html('');
                }
                var HTML = fnHandlebarTemplate('template-inbox-list-v2', data);
                //$('#uListCategoryDetail .js-cat-load-more-container').remove();
                $('#dvCategContentList').append(HTML);
                $('#uListCategoryDetail  #categoryLoader').remove();

                var moduleCount = data.moduleInbox.length;
                if (moduleCount == 0) {
                    $('#dvCategContentList').append('<div class="card__content card__padding text-center"><article class="card__article"><h3>No Notifications Available</h3></article></div>');
                    $("#btnLoadMoreCategoryDetail").addClass("hide");
                    return;
                }
                $("#btnLoadMoreCategoryDetail").removeClass("hide");

                _maxInboxId = data.moduleInbox[moduleCount - 1].Inbox_id;

                //Show load more
                if ((moduleCount < _maxInboxResult)) {
                    loadMore = false;
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                //Highligh the inbox wala tab
                $('.js-menu-item').removeClass('active');

                //Store the app notification data
                var arrAppNoti = _.filter(data.moduleInbox, {
                    content_json: {
                        sub_type: 'app_noti'
                    }
                });

                _.forEach(arrAppNoti, function(objModule) {
                    var objNotiData = objModule.content_json.noti_data;
                    var appData = objNotiData.app_data;

                    if (appData) {
                        storeNoti.save({
                            key: 'noti-' + objNotiData.noti_id,
                            data: JSON.parse(appData)
                        });
                    }
                });

                // Reset unread inbox badge count
                storeUser.save({
                    key: 'unread-inbox',
                    data: 0
                });

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    $('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            }
        }

        var postData = JSON.stringify({
            uid: user_id,
            inbox_id: _maxInboxId,
            inbox_count: _maxInboxResult
        });
        var valPresent = jQuery.inArray(catContent, allJsonKeys)
        if (valPresent > -1) {
            var catContentData = getJsonData("catContent");
            onSuccess(catContentData);
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }
    }

    var _maxBookmarkId = 0;
    var _maxBookmarkResult = 20;
    var _loadBookmark = function() {
        $('#bookmark').addClass('active');
        $('#inbox').removeClass('active');
        $('#spPaneName').text('Bookmark');
        var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');
        if (_maxBookmarkId === 0) {
            $('#dvCategContentList').html('');
        }
        $('#uListCategoryDetail').append($vatLoaderTemp);

        //Highligh the inbox wala tab
        $('.js-menu-item').removeClass('active');
        $('.js-appitem').removeClass('active');

        var postData = {
            type: 'getMyBookmark',
            data: {
                uid: user_id,
                bookmark_id: _maxBookmarkId,
                bookmark_count: _maxBookmarkResult
            }
        };

        var fnSuccess = function(respData) {
            var data = JSON.parse(respData);

            if (data.user_bookmark) {
                var moduleCount = data.user_bookmark.length;
                if ((moduleCount < _maxBookmarkResult)) {
                    loadMore = false;
                    $('#tempLoadMoreCategDetail').addClass('hide');
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                var HTML = fnHandlebarTemplate('tmpl-bookmark-v2', data);
                //$('#uListCategoryDetail .js-cat-load-more-container').remove();
                $('#dvCategContentList').append(HTML);
                $('#uListCategoryDetail #categoryLoader').remove();

                if (moduleCount > 0) {
                    _maxBookmarkId = data.user_bookmark[moduleCount - 1].bookmark_id;
                }

                //Show load more


            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    $('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            }
        };

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, fnSuccess, onError);
    }

    //comments list function
    //Show in that box
    var _loadCommentlist = function(cId) {
        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            //Hide the loader
            $('#dvCommentList').find('.list-loading').addClass('hide');

            //Reset the comment textbox height
            $('#txtAddComment').val('').trigger('input');

            if (data.comment_list) {
                var HTML = fnHandlebarTemplate('template-comment-list', data);
                var length = data.comment_list.length;

                $('#dvCommentList').find('.list-content > ul').html(HTML);
            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {} else if (errorCode == 1) {

                } else if (errorCode == 2) {

                } else if (errorCode == 3) {
                    afterSessionTimeOut();
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "getComments",
            data: {
                uid: user_id,
                cid: cId
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _objUserList = {
        start_index: 0
    };

    var _loadUserList = function() {

        function onSuccess(respData) {
            var objData = JSON.parse(respData);

            //Update pointer
            if (objData.user_list) {

                if (objData.user_list.length === 0) {
                    $('#btnLoadMoreRecommList').addClass('hide');
                } else {
                    $('#btnLoadMoreRecommList').removeClass('hide');
                }

                _objUserList.start_index = _objUserList.start_index + 25;

                //Hide the loader
                $('#dvRecommList').find('.list-loading').addClass('hide');
                $('#btnLoadMoreRecommList').prop('disabled', false);

                //Get HTML from template 
                var HTML = fnHandlebarTemplate('tmpl-recomm-list', objData);
                $('#dvRecommList').find('.list-content > ul').append(HTML);
            } else if (objData.resp == '2') {
                $('#btnLoadMoreRecommList').addClass('hide');
                $('#dvRecommList').find('.list-loading').addClass('hide');
            }


        }

        var postData = {
            type: 'getUserList',
            data: {
                uid: user_id,
                start_index: _objUserList.start_index,
                expected_size: 25,
                start_with_alphabet: '',
                search_text: $.trim($('#txtSearchRecommList').val())
            }
        }

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);

    }

    var _fnSetRating = function(appRating) {
        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
        }
        //AppCatalogue.aspx

        var postData = JSON.stringify({
            type: "ratePluginApp",
            data: {
                uid: user_id,
                icon_id: 678,
                icon_type: "a",
                app_version: "1.2.3",
                rating: 4
            }
        });

        fnAjaxRequest(API_BASE_URL + 'AppCatalogue.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //Send contnet recommendation
    var _sendRecomm = function(contId, toUserId, $thisBtn) {
        //Show loading on this button
        var ladda = $thisBtn.ladda();
        // Start loading
        ladda.ladda('start');

        function onSuccess(data) {
            ladda.ladda('stop');

            var objData = JSON.parse(data);

            if (objData.success) {
                $thisBtn.next().removeClass('hide');
                $thisBtn.remove();
            }
        };

        var postData = {
            type: 'setRecommend',
            data: {
                uid: user_id,
                cid: contId,
                recomm_to_uid: [toUserId]
            }
        };

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);
    }

    //delete inbox entry
    var _delInboxEntry = function(inbxid, callback) {

        var deferred = Q.defer();

        function onSuccess(respdata) {
            //callback();
            var data = JSON.parse(respdata);

            if (data.success) {
                //_maxInboxId = 0;
                //_loadInbox();

                deferred.resolve(data);
            }

            //else if (data.resp) {
            //    var errorCode = data.resp;
            //    if (errorCode == 0) {
            //        swal('Oops!', 'Server error!', 'error');
            //    }
            //    else if (errorCode == 1) {
            //        swal('Oops!', 'Invalid request', 'error');
            //    }
            //    else if (errorCode == 3) {
            //        swal("Invalid User.");
            //    }
            //}

        }

        var postData = JSON.stringify({
            type: "deleteInboxContent",
            data: {
                uid: user_id,
                inbox_id: inbxid
            }
        });

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //add comments function
    var _addcomment = function(cId, user_comment) {

        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            //Enable the button
            $('#btnPostComment').prop('disabled', false);
            $('#txtAddComment').val('');
            if (data.success) {

                var objComment = {
                    comment_list: [{
                        comment_date: '',
                        user_comment: user_comment,
                        user_name: objUser.user_name,
                        user_profile_url: objUser.user_profile_image
                    }]
                };

                var HTML = fnHandlebarTemplate('template-comment-list', objComment);
                var $ulComment = $('#dvCommentList').find('.list-content > ul');
                $ulComment.append(HTML);
                $ulComment.animate({
                    scrollTop: $ulComment.prop("scrollHeight")
                }, 500);

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {

                } else if (errorCode == 3) {
                    afterSessionTimeOut();

                } else if (errorCode == 4) {

                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "addComment",
            data: {
                uid: user_id,
                cid: cId,
                user_comment: user_comment
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //Set Favourites function
    var _setFavouriteApps = function (FavouritesJson) {
        var deferred = Q.defer();

        function onSuccess(respdata) {
            console.log(respdata);
            deferred.resolve(respdata);
        }
        function onError(respdata) {
            console.log(respdata);
        }

        var postData = JSON.stringify({
            type: "setFavIcon",
            data: FavouritesJson
        });

        fnAjaxRequest(API_BASE_URL + 'AppCatalogue.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //add like function
    var _addlike = function (cid, likeStatus) {
        var deferred = Q.defer();

        if (likeStatus == "0") {
            //Remove filled
            $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');
        } else {
            //Set filld
            $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhitefilled.png');
        }

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.success) {
                $('#btnLikeCont').data('likeStatus', likeStatus);
            } else if (data.resp) {
                //Reset image switch
                if (likeStatus == "0") {
                    //Remove filled
                    $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhitefilled.png');
                } else {
                    //Set filld
                    $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "setLike",
            data: {
                uid: user_id,
                cid: cid,
                like_status: likeStatus
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);

        return deferred.promise;
    }

    //add bookmark function
    var _addbkmrk = function (cid, bkmrkStatus) {
        var deferred = Q.defer();

        //Show that wala image
        if (bkmrkStatus == "0") {
            //Remove filled
            $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
        } else {
            //Set filld
            $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhitefilled.png');
        }

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.success) {
                $('#btnBookmarkCont').data('bookmarkStatus', bkmrkStatus);
            } else if (data.resp) {
                //Reset image switch
                if (bkmrkStatus == "0") {
                    //Remove filled
                    $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhitefilled.png');
                } else {
                    //Set filld
                    $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "setBookmark",
            data: {
                uid: user_id,
                cid: cid,
                bookmark_status: bkmrkStatus
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _getbkmrks = function () {
        var deferred = Q.defer();
        /* ALSO UPDATE THE ONSUCCESS */
        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        var postData = JSON.stringify({
            type: "getMyBookmark",
            data: {
                uid: user_id,
                bookmark_id: 1,
                bookmark_count: 10
            }
        });

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //get worth-its/like function
    var _loadlikelist = function(cId) {

        var deferred = Q.defer();

        $('#comment_box').removeClass('hidden');

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.likes_list) {
                $('#likesList').html('');

                var HTML = fnHandlebarTemplate('template-like-list', data);
                var length = data.likes_list.length;

                $("#likecount").html(length);
                $('#likesList').append(HTML);
            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    $('#likesList').html('Oops! No Likes!Be the first to like');

                } else if (errorCode == 3) {
                    // swal({
                    //     title: "Oops",
                    //     text: "Session Expired",
                    //     closeOnConfirm: true
                    // });
                    afterSessionTimeOut();
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "getLikes",
            data: {
                uid: user_id,
                cid: cId
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);

        return deferred.promise;
    }

    //analytics functions
    var article_accessed = function(contId, timeSpent) {
        //var conId = "4090";
        //var timeSpent = "5";
        var in_browser = "1";
        var from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "articleWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                in_browser: in_browser,
                from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var embed_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var in_browser = "1";
        var from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "embedWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                in_browser: in_browser,
                from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var video_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var watch_from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "videoWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                watch_from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var pdf_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var watch_from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "pdfWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var _webViewPopup = function(webUrl, alreadyOpen, yoCustomHome, appId) {

        var iframeId = 'frameWebview';
        $('#dvWebviewMsg').removeClass('hide');
        if (yoCustomHome) {
            iframeId = 'frmCustomHome';
            $('#dvWebviewMsg').addClass('hide');
        }

        // Check if Cordova webview is initialized
        if (typeof objCordovaWebView != 'undefined') {
            //Set the current iframe
            objCordovaWebView.changeIFrame(iframeId);
        } else {
            //Initialize the cordova webview
            objCordovaWebView = new CordovaWebview();
            objCordovaWebView.init(iframeId);
        }

        if (appId > 0) {
            objCordovaWebView.setAppId(appId);
        }

        if (!alreadyOpen) {
            $modal = $('#dvWebView');
            $overlay = $modal.next();
            $overlay.addClass('state-show');
            $modal.removeClass('state-leave').addClass('state-appear');
        }

        $('#loaderIframeWebView').removeClass('hide');

        //Hide the headr
        $modal.find('.aw-modal-header').addClass('webview');

        //Hide the content div
        $('#dvContentContainer').addClass('hide');


        if (yoCustomHome) {
            $('#frmCustomHome').removeClass('hide').attr('src', webUrl);
            $('#frameWebview').addClass('hide');
        } else {
            $('#frameWebview').removeClass('hide').attr('src', webUrl);
            $('#frmCustomHome').addClass('hide');
        }
    }

    /* WORK IN PROGRESS */
    var _handleTheMedia = function(mediaUrl, mediaType) {
        var deferred = Q.defer();
        /* ALSO UPDATE THE ONSUCCESS */
        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        var postData = JSON.stringify({
            type: "getMyBookmark",
            data: {
                uid: user_id,
                bookmark_id: 1,
                bookmark_count: 10
            }
        });
        /* LATER DO UPDATE THE URL TO HIT hehehe */
        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _resetBadge = function() {
        var deferred = Q.defer();

        function onSuccess() {
            setJsonData('getContent', '{"module":[]}');
            var data = getJsonData('getContent');
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        onSuccess();
        return deferred.promise;
    }

    var _makeCustomHomePopup = function() {
        //Hide the topbar
        $('#dvModalHeader').addClass('hide');

        //Increase the width
        $('#dvWebView').find('.aw-modal').addClass('custom-home');

        //Set body
        $('body').addClass('is-customhome');
    };

    //Validate that the quiz/survey is filled
    var _fnValidateQuestionnaire = function() {

        var isValid = true;
        var objOptSelected = [];
        $('#dr-quiz-qa-section').find('.js-quiz-ques').each(function(index, value) {
            var $thisQ = $(value);
            var thisQType = $thisQ.data('qType');

            if (thisQType === 'MCQ' || thisQType === 'MRQ') {
                var thisSelectedOpt = $thisQ.find('.js-quiz-opt.selected').length;
                if (thisSelectedOpt === 0) {
                    //Oopsie!
                    //var $currQ = $('#dr-quiz-qa-section').find('.js-quiz-ques:last-child');

                    //$thisQ.addClass('active').addClass('quiz-ques-error');
                    //$currQ.removeClass('active');

                    //_switchDivsAnimated($currQ, $thisQ, 'ltr');
                    //$('#btnNextQuestion').parent().removeClass('hide');
                    ////Hide submit wala button
                    //$('#btnSubmitQuiz').addClass('hide');
                    //if (index === 0) {
                    //    $('#btnPrevQuestion').parent().addClass('hide');
                    //}

                    //isValid = false;
                    //return false;

                    var objThisOpt = {};
                    objThisOpt.o = [];
                    objThisOpt.qtype = thisQType;

                    objOptSelected.push(objThisOpt);
                } else {
                    var objThisOpt = {};
                    objThisOpt.o = [];
                    objThisOpt.qtype = thisQType;
                    //Add to that
                    $thisQ.find('.js-quiz-opt').each(function(index, value) {
                        var $this = $(value);
                        if ($this.hasClass('selected')) {
                            objThisOpt.o.push(index + 1 + '');
                        }
                    });
                    objOptSelected.push(objThisOpt);
                    //$thisQ.removeClass('quiz-ques-error');
                }
            } else if (thisQType === 'Sub') {
                var thisQVal = $.trim($thisQ.find('.js-ques-text').val());

                var objThisOpt = {};
                objThisOpt.o = [thisQVal];
                objThisOpt.qtype = thisQType;

                objOptSelected.push(objThisOpt);
            } else if (thisQType === 'Rating') {
                var thisQVal = $thisQ.find('.star-rating').find('input:checked').val();

                var objThisOpt = {};
                objThisOpt.o = [thisQVal];
                objThisOpt.qtype = thisQType;

                objOptSelected.push(objThisOpt);
            }
        });

        return objOptSelected;
    }

    var objPPTSeen = {
        cid: 0,
        slide: []
    };

    var _pptAnalysis = function() {
        var postData = {
            type: 'presentationWatched',
            data: {
                uid: user_id,
                cid: objPPTSeen.cid,
                time_spent: 0,
                slide_seen: objPPTSeen.slide
            }
        };
        var onSuccess = function() {};
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);
    }

    var _fnAppendUserId = function(webUrl, notiId) {
        // var sso = localStorage.getItem('sso');
        var appUrl = '';
        if (sso) {
            var objSSO = JSON.parse(sso);
            if (webUrl.indexOf('?') > -1) {
                //QString exists
                appUrl = webUrl + '&dm_eid=' + encodeURIComponent(objSSO.uid);
            } else {
                appUrl = webUrl + '?dm_eid=' + encodeURIComponent(objSSO.uid);
            }
        } else {
            if (webUrl.indexOf('?') > -1) {
                //QString exists
                appUrl = webUrl + '&dm_uid=' + user_id;
            } else {
                appUrl = webUrl + '?dm_uid=' + user_id;
            }
        }

        //append noti_id if any
        if (notiId) {
            appUrl = appUrl + '&dm_noti_id=' + notiId;
        }

        return appUrl;
    }

    //fn: add events
    var _onEvent = function() {

        //Event: click category app item 
        $('body').off('click', '.js-appitem').on('click', '.js-appitem', function() {

            var $this = $(this);

            $('#inbox').removeClass('active');
            $('#bookmark').removeClass('active');

            if ($(this).hasClass("folderitemparent")) {
                if ($(this).hasClass("active")) {
                    $(this).removeClass("active");
                    $(this).find(".pull-right i").removeClass("rotateup");
                } else {
                    $(this).addClass("active");
                    $(this).find(".pull-right i").addClass("rotateup");
                }
            }
            if ($(this).data('catid')) {
                startIndex = 0;

                var catId = $(this).data('catid');
                $('#uListCategoryDetail').html('');
                loadMore = true;
                _loadCatDetail(catId, true);

                //Show the name of this category on the pane
                var catName = $this.find('.media-body span').text();
                $('#spPaneName').text(catName);

                $('#btnLoadMoreCategoryDetail').off('click').on('click', function(e) {
                    _loadCatDetail(catId, true);
                });
            } else if ($(this).data('abid')) {
                var appAction = $(this).data('action').toLowerCase();
                var appId = $(this).data('abid');
                if (appAction == "webview") {
                    var srcif = $(this).data('srcurl');

                    srcif = _fnAppendUserId(srcif);

                    _webViewPopup(srcif, false, false, appId);
                } else if (appAction == "localview" || appAction == "internalview") {
                    //Check if this is packge type which supports web access
                    var objData = JSON.parse(decodeURIComponent(atob($(this).data('objData'))));

                    if (objData.sub_type === 'plugin') {
                        var webUrl = objData.plugin_version.web_url;
                        if (webUrl.length > 0) {
                            if (objData.plugin_version.hide_close_button) {
                                //Hide the headr
                                $('#dvModalHeader').addClass('hide');
                            }
                            _webViewPopup(webUrl, false, false, appId);
                            return;
                        }
                    }

                    swal("This is not available on the web!");
                } else if (appAction == "folderview") {
                    var objdata = $(this).data('folderviewobj');
                } else {
                    swal("This is not available on the web!");
                }
            }
        });

        $('body').off('click', '.list-group-item').on('click', '.list-group-item', function() {
            $(this).addClass('selected').siblings(".selected").removeClass('selected');
        });

        //loading the inbox on click
        $('body').off('click', '#inbox').on('click', '#inbox', function() {
            _maxInboxId = 0;
            _loadInbox();

            $('#btnLoadMoreCategoryDetail').off('click').on('click', function(e) {
                e.preventDefault();

                _loadInbox();
            });
        });

        $('#bookmark').off('click').on('click', function() {
            _maxBookmarkId = 0;
            _maxBookmarkResult = 20;
            _loadBookmark();
            $('#btnLoadMoreCategoryDetail').off('click').on('click', function(e) {
                e.preventDefault();

                _loadBookmark();
            });
        });

        //Event: click content in category detail list
        $('body').off('click', '.js-category-detail-item').on('click', '.js-category-detail-item', function() {

            var cType = $(this).data('ctype');
            var cId = $(this).data('cid');

            var timespent = _loadCatContent(cId, cType);

            $("#add_Coments").removeClass("hidden");
            $('#commentList').html('');
            _loadCommentlist(cId);
            _addcommentHelper(cId, false);
            _loadlikelist(cId);
            $("#commentcount").html('');
            $("#likecount").html('');
            switch (cType) {
                case 'article':
                    article_accessed(cId, timespent);
                    break;

            }
        });

        $('body').off('click', '.js-categ-item').on('click', '.js-categ-item', function(cId, cType) {

            $('#dvContentListContainer').addClass('hide');
            $('.closewalaCMS').remove();
            var cType = $(this).data('type');
            var cId = $(this).data('cid');
            $('#loaderIframeWebView').removeClass('hide');
            var timespent = _loadCatContent(cId, cType);

            $('#dvContentMeta').removeClass('hide');
            $('#dvContentThirdScreen').addClass('hide');

            //Open that popup
            $modal = $('#dvWebView');
            $overlay = $modal.next();
            $overlay.addClass('state-show');
            $modal.removeClass('state-leave').addClass('state-appear');
            $modal.find('.aw-modal-header').addClass('webview');

            $('#dvIframeContainer').addClass('hide');

            //Set parameters
            $('#dvModalHeader').data('mode', 'CONT');
            $('#dvModalHeader').data('cid', cId);
            $('#dvModalHeader').data('type', cType);

            //Reset status
            $('#btnBookmarkCont').data('bookmarkStatus', '0').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
            $('#btnLikeCont').data('likeStatus', '0').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');

            //Hide comment/recomm list
            $('#dvCommentList').addClass('hide');
            $('#dvRecommList').addClass('hide');

            return false;
        });

        $('#log_out').on('click', function() {
            _logout(true);
        });

        $('body').off('click', '.like_btn').on('click', '.like_btn', function() {
            var cid = $(this).data('cid');
            var status = $(this).data('status');
            if (status == 1) {
                _addlike(cid, status);

            } else if (status == 0) {

                $("#liked").addClass("active");

            }
        });

        $('body').off('click', '.bkmrk_btn').on('click', '.bkmrk_btn', function() {
            var cid = $(this).data('cid');
            var status = $(this).data('status');
            _addbkmrk(cid, status);
        });

        $('body').off('click', '.folderview_listitem').on('click', '.folderview_listitem', function() {
            loadMore = true;

            $('#uListCategoryDetail').html('');

            if ($(this).data('cid')) {
                startIndex = 0;
                var catId = $(this).data('cid');
                _loadCatDetail(catId, true);

                $('#btnLoadMoreCategoryDetail').off('click').on('click', function(e) {
                    _loadCatDetail(catId, false);
                });
            } else if ($(this).data('abid')) {
                var appId = $(this).data('abid');
                if ($(this).data('action') == "WebView") {
                    var srcif = $(this).data('srcurl');

                    srcif = _fnAppendUserId(srcif);

                    _webViewPopup(srcif, false, false, appId);

                } else if ($(this).data('action') == "localview") {
                    swal("App is not supported!");
                } else if ($(this).data('action') == "folderview") {

                    var objdata = $(this).data('folderviewobj');


                } else {
                    swal("Unsupported selection !! Please try again");
                }

            }

        });

        var _addcommentHelper = function(cId, user_comment) {
            $('body').off('click', '#comment_submit').on('click', '#comment_submit', function() {

                user_comment = $("#comment_text").val();
                if (user_comment == '') {
                    swal("U cant put an empty comment")
                } else {
                    $("#comment_submit").text("Posting..")
                    $("#comment_submit").attr("disabled", true);
                    _addcomment(cId, user_comment);
                }
            });



            $("#comment_text").keypress(function(e) {
                var key = e.which;
                if (key == 13) // the enter key code
                {
                    $('#comment_submit').click();
                    // return false;
                }
            });
        }

        $('#frameWebview').off('load').on('load', function(e) {
            //Hide the loader div
            //Show the iframe div

            $('#loaderIframeWebView').addClass('hide');
            $('#dvIframeContainer').removeClass('hide');
        });

        $('#frmCustomHome').off('load').on('load', function(e) {
            //Hide the loader div
            //Show the iframe div

            $('#loaderIframeWebView').addClass('hide');
            $('#dvIframeContainer').removeClass('hide');
        });

        //Start Third Screen
        $('#dvContentContainer').off('click', '#btnStartThirdScreen').on('click', '#btnStartThirdScreen', function(e) {
            e.preventDefault();

            var $this = $(this);
            var thisType = $this.data('type');
            var thisContId = $this.data('cid');
            var thisData = $this.data('yoData');

            thisData = decodeURIComponent(atob(thisData));

            var thisTemplate = '';
            var objData = {};
            $('#dvContentThirdScreen').removeClass('height100p');
            switch (thisType) {
                case "q":
                case "s":
                    {
                        thisTemplate = 'tmpl-quiz-inner';
                        var objData = {
                            question: JSON.parse(thisData),
                            cid: thisContId,
                            type: thisType
                        };
                        break;
                    }
                case "p":
                    {
                        thisTemplate = 'tmpl-slide-inner';
                        var objData = {
                            slide: JSON.parse(thisData),
                            cid: thisContId
                        };
                        objPPTSeen.slide = ["1"];
                        objPPTSeen.cid = thisContId;
                        break;
                    }
                case "pdf":
                    {
                        thisTemplate = 'tmpl-pdf-inner';
                        var objData = {
                            pdf_url: JSON.parse(thisData),
                            cid: thisContId
                        };

                        $('#dvContentThirdScreen').addClass('height100p');

                        break;
                    }
            }

            if (!thisTemplate)
                return;



            var thisHTML = fnHandlebarTemplate(thisTemplate, objData);

            var $dvMeta = $('#dvContentMeta')
            var $dvThird = $('#dvContentThirdScreen');

            $dvThird.html(thisHTML);

            _switchDivsAnimated($dvMeta, $dvThird, 'rtl');
        });

        //Next quiz question
        $('#dvContentContainer').off('click', '#btnNextQuestion').on('click', '#btnNextQuestion', function(e) {
            var $activeQues = $('#dr-quiz-qa-section').find('.js-quiz-ques.active');
            var $nextQues = $activeQues.next();

            $nextQues.addClass('active');
            $activeQues.removeClass('active');
            _switchDivsAnimated($activeQues, $nextQues, 'rtl');

            //Hide this button if next one is last one
            var nextIsLast = $nextQues.is(':last-child');
            var prevIsFirst = $activeQues.is(':first-child');

            if (nextIsLast) {
                $(this).parent().addClass('hide');
                //Show submit wala button
                $('#btnSubmitQuiz').removeClass('hide');
            }
            if (prevIsFirst) {
                $('#btnPrevQuestion').parent().removeClass('hide');
            }
        });

        //Previous quiz question
        $('#dvContentContainer').off('click', '#btnPrevQuestion').on('click', '#btnPrevQuestion', function(e) {
            var $activeQues = $('#dr-quiz-qa-section').find('.js-quiz-ques.active');
            var $nextQues = $activeQues.prev();
            $nextQues.addClass('active');
            $activeQues.removeClass('active');
            _switchDivsAnimated($activeQues, $nextQues, 'ltr');

            var nextIsFirst = $nextQues.is(':first-child');
            var prevIsLast = $activeQues.is(':last-child');

            if (nextIsFirst) {
                $(this).parent().addClass('hide');
            }
            if (prevIsLast) {
                $('#btnNextQuestion').parent().removeClass('hide');
                //Hide submit wala button
                $('#btnSubmitQuiz').addClass('hide');
            }
        });

        //Select Option
        $('#dvContentContainer').off('click', '.js-quiz-option').on('click', '.js-quiz-option', function(e) {

            var $thisQues = $(this).parents('.js-quiz-ques');
            var $thisParent = $(this).parents('.dr-col-option-ans');

            var thisQType = $thisQues.data('qType');

            if (thisQType === 'MCQ') {
                $thisQues.find('.dr-col-option-ans').not($thisParent).removeClass('selected');
            }

            $thisParent.toggleClass('selected');

            var selectedOption = $thisQues.find('.dr-col-option-ans.selected').length;
            if (selectedOption > 0) {
                $thisQues.addClass('selected');
            } else {
                $thisQues.removeClass('selected');
            }


            //Process Quiz progress
            var $theQuiz = $('#dr-quiz-qa-section');

            var completQuesCount = $theQuiz.find('.js-quiz-ques.selected').length;
            var totalQuesCount = $theQuiz.find('.js-quiz-ques').length;

            var percent = Math.round((completQuesCount / totalQuesCount) * 100, 2) + '%';

            $('#dr-quiz-progress-bar').css('width', percent);
            $('#dr-quiz-progress-bar-count').text(percent);
        });

        //Submit Quiz/Survey
        $('#dvContentContainer').off('click', '#btnSubmitQuiz').on('click', '#btnSubmitQuiz', function(e) {
            //Check if this is survey or quiz
            var $this = $(this)
            var contType = $this.data('type');
            var contId = $this.data('cid');

            //Validate that form is filled
            var arrOptSelected = _fnValidateQuestionnaire(contType);

            //If yes then submit to the server
            var reqType = '';
            if (contType === 's') {
                reqType = 'surveyWatched';
            } else if (contType === 'q') {
                reqType = 'quizWatched';
            }

            var postData = {
                type: reqType,
                data: {
                    uid: user_id,
                    cid: contId,
                    time_spent: 0,
                    options_selected: arrOptSelected
                }
            };

            $this.prop('disabled', true);

            var onSuccess = function(data) {
                var objData = JSON.parse(data);

                if (objData.success) {
                    var message = 'Thank you for submitting your response.';
                    if (contType === 'q') {
                        if (objData.result) {
                            message = objData.result;
                        }
                    }

                    swal({
                        title: "",
                        text: message,
                        type: "success",
                        confirmButtonColor: "#28bc6a",
                        confirmButtonText: "Okay!",
                        closeOnConfirm: true
                    }, function() {
                        _fnActualCloseModal();
                    });
                } else {
                    sweetAlert("Oops...", "Something went wrong!", "error");
                }
            }

            fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: JSON.stringify(postData)
            }, onSuccess, onError);
        });

        //Open comment box
        $('#btnShowCommentList').off('click').on('click', function(e) {
            e.preventDefault();

            var $listBox = $('#dvCommentList');
            $listBox.find('.list-content > ul').empty();
            $listBox.removeClass('hide').addClass('animated fadeInDown').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeInDown');
            });

            var contId = $('#dvModalHeader').data('cid');

            _loadCommentlist(contId);
        });

        //Open recommend list
        $('#btnShowRecommList').off('click').on('click', function(e) {
            e.preventDefault();

            var $listBox = $('#dvRecommList');
            $listBox.find('.list-content > ul').empty();
            $listBox.removeClass('hide').addClass('animated fadeInDown').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeInDown');
            });

            var contId = $('#dvModalHeader').data('cid');

            _objUserList.start_index = 0;
            $('#txtSearchRecommList').val('');

            //Load list of user for recomm
            _loadUserList();
        });

        $('.list-close').off('click').on('click', function(e) {
            e.preventDefault();

            var $listBox = $(this).parents('.list-box');

            $listBox.addClass('animated fadeOut').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeOut').addClass('hide');
            });
        });

        //Post comment
        $('#btnPostComment').off('click').on('click', function(e) {
            var thisComment = $.trim($('#txtAddComment').val());
            var contId = $('#dvModalHeader').data('cid');

            if (thisComment.length === 0) {
                return;
            }

            _addcomment(contId, thisComment);

            $(this).prop('disabled', true);
        });

        //Search recomm list
        $('#btnSearchRecommList').off('click').on('click', function(e) {
            var $listBox = $('#dvRecommList');
            $listBox.find('.list-content > ul').empty();

            $('#dvRecommList').find('.list-loading').removeClass('hide');

            _objUserList.start_index = 0;

            _loadUserList();
        });

        //Send recomm to user
        $('#dvRecommList').off('click', '.js-send-recomm').on('click', '.js-send-recomm', function(e) {
            var $this = $(this);
            var recommToUserId = $this.data('toUserId');
            var contId = $('#dvModalHeader').data('cid');

            _sendRecomm(contId, recommToUserId, $this);
        });

        //Load more user list
        $('#btnLoadMoreRecommList').off('click').on('click', function(e) {
            e.preventDefault();

            $('#dvRecommList').find('.list-loading').removeClass('hide');

            _loadUserList();
        });

        //Bookmark a content
        $('#btnBookmarkCont').off('click').on('click', function(e) {
            e.preventDefault();

            var contId = $('#dvModalHeader').data('cid');
            var currentStatus = $(this).data('bookmarkStatus');
            var newStatus = "";
            if (currentStatus == "0")
                newStatus = "1";
            else
                newStatus = "0";

            _addbkmrk(contId, newStatus)
        });

        //Like a content
        $('#btnLikeCont').off('click').on('click', function(e) {
            e.preventDefault();

            var contId = $('#dvModalHeader').data('cid');
            var currentStatus = $(this).data('likeStatus');
            var newStatus = "";
            if (currentStatus == "0")
                newStatus = "1";
            else
                newStatus = "0";

            _addlike(contId, newStatus)
        });

        //Event of slide next/prev
        $('#dvContentContainer').on('slid.bs.carousel', '#carousel-slide-deck', function(e) {
            var thisIndex = $(e.relatedTarget).data('index');

            objPPTSeen.slide.push(thisIndex + 1 + '');
        });

        $('#lnkBackFromInbox').on('click', function(e) {
            e.preventDefault();

            var $modal = $('#dvWebView');
            var $overlay = $modal.next();
            $overlay.addClass('state-show');
            $modal.removeClass('state-leave').addClass('state-appear');

            $('#frmCustomHome').removeClass('hide');
            $('#frameWebview').addClass('hide');
            $('#dvModalHeader').addClass('hide');
            $('#dvMainSection').addClass('hide');
        });

        // Delete Inbox Content 
        $('body').popover({
            selector: '.js-delete-inbox-popup',
            trigger: 'focus',
            content: function(e) {
                var inboxId = $(this).data('inboxId');
                return $('#dvConfirmNotiDelete').html().replace('{{inbox_id}}', inboxId);
            },
            html: true,
            placement: 'left'
        });

        $('body').on('click', '.js-delete-inbox', function(e) {
            var inboxId = $(this).data('inboxId');
            var $parentCard = $(this).parents('.card');

            startDivBlock($parentCard);

            _delInboxEntry(inboxId, function() {
                stopDivBlock($parentCard);
                $parentCard.fadeOut(function() {
                    $parentCard.remove();
                });
            });
        });
    }

    var _switchDivsAnimated = function($dv1, $dv2, dir) {
        if (dir === 'rtl') {
            $dv1.addClass('animated fadeOutLeft').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeOutLeft').addClass('hide');
            });
            $dv2.removeClass('hide').addClass('animated fadeInRight').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeInRight');
            });
        } else {
            $dv1.addClass('animated fadeOutRight').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeOutRight').addClass('hide');
            });
            $dv2.removeClass('hide').addClass('animated fadeInLeft').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated fadeInLeft');
            });
        }
    };

    var _fnGetCloseMsg = function(contType) {
        var msg = "Are you sure you want to exit";
        switch (contType) {
            case "v":
                {
                    return msg + '?';
                }
            case "audio":
                {
                    return msg + '?';
                }
            case "text":
                {
                    return msg + '?';
                }
            case "pdf":
                {
                    return msg + '?';
                }
            case "n":
                {
                    return msg + '?';
                }
            case "article":
                {
                    return msg + '?';
                }
            case "p":
                {
                    return msg + '?';
                }
            case "q":
                {
                    return msg + ' without submitting your answers?';
                }
            case "s":
                {
                    return msg + ' without submitting your responses?';
                }
            case "embed":
                {
                    return msg + '?';
                }
            case "ig":
                {
                    return msg + '?';
                }
            case "form":
                {
                    return msg + '?';
                }
        }
    }

    var _fnActualCloseModal = function() {
        $overlay.removeClass('state-show');
        //$modal.removeClass('state-appear').addClass('state-leave');
        $('.closewalaCMS').addClass('hide');
        
        //reset the cordovawebview
        $('#frameWebview').attr('src', 'about:blank');
        $('#dvIframeContainer').addClass('hide');

        //reset the CMS frame
        $('#dvContentContainer').addClass('hide');
        $('#dvContentMeta').empty().removeClass('hide');
        $('#dvContentThirdScreen').empty().addClass('hide');

        //Reset the loading in a bit
        $('#loaderIframeWebView').removeClass('hide');

        $modal.find('.aw-modal-header').removeClass('hide');
        $('#dvModalHeader').addClass('hide');
        $('.aw-modal-body').css('padding-bottom','0px');
        $('.aw-modal-body').css('height','100%');
    };

    var _fnContentAnalysis = function() {};

    var _fnCloseAwesomeModal = function(byPass) {
        if (byPass !== true) {
            var modalMode = $('#dvModalHeader').data('mode');
            var contType = $('#dvModalHeader').data('type');
            if (modalMode === 'CONT') {
                if (contType === 'q' ||
                    contType === 's' ||
                    contType === 'p') {
                    var msg = _fnGetCloseMsg(contType);

                    _fnContentAnalysis = _pptAnalysis;

                    //Confirm from the user
                    $('#confirmCloseModal').find('.popup-message').text(msg);
                    $('#confirmCloseModal').addClass('is-visible');
                } else {
                    //Analytics & all
                    _fnActualCloseModal();
                }
            } else {
                _fnActualCloseModal();
            };
        } else {
            _fnActualCloseModal();
        }
    };

    var $modal, $overlay;

    var _awesomeModal = function(yoCustomHome) {
        $modal = $('.aw-modal-frame');
        $overlay = $('.aw-modal-overlay');

        /* Need this to clear out the keyframe classes so they dont clash with each other between ener/leave. Cheers. */
        $modal.bind('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
            if ($modal.hasClass('state-leave')) {
                $modal.removeClass('state-leave');
            }
        });

        $modal.find('.close').on('click', function() {
            //_fnCloseAwesomeModal();
            //now just custom home so new funda to hide modal and show custom home screen
            $("#dvIframeContainer").removeClass("hide");
            $("#dvContentContainer").addClass("hide");
            $('#dvWebView').find('.aw-modal').addClass('custom-home');
            $('#dvWebView').find('#dvModalHeader').addClass('hide');
            $("#loaderIframeWebView").addClass("hide");
            $("#frameWebview").addClass("hide");
            $("#frmCustomHome").removeClass("hide");
        });

        if (!yoCustomHome) {
            var windowWidth = $(window).width();
            var asideWidth = (windowWidth - 760) / 2;
            $('.aw-modal-aside').css('width', asideWidth + 'px');
        }

        //Awesome alert
        $('#confirmCloseModal').on('click', function(event) {
            if ($(event.target).is('.cd-popup-close') || $(event.target).is('.cd-popup') || $(event.target).is('#btnNoThePopup')) {
                event.preventDefault();
                $(this).removeClass('is-visible');
            }
        });

        $('#btnYesThePopup').on('click', function(e) {
            e.preventDefault();
            $('#confirmCloseModal').removeClass('is-visible');

            //Sent analytical report for this content
            _fnContentAnalysis();

            _fnActualCloseModal();
        });
    };

    //loading inbox by default //
    var _defaultview = function() {
        $("#inbox").trigger('click');
    }

    var _fnApplyAppMeta = function() {
        // var objAppMeta = JSON.parse(localStorage.getItem('appMeta'));
        var objAppMeta = getJsonData('appMeta');
        var imgsrc = objAppMeta.top_bar_icon.img_xhdpi;
        var appName = objAppMeta.top_bar_text;

        $('#imgAppLogo').attr('src', imgsrc);
        $('#spAppName').text(appName);
    }

    var _initPlugins = function() {
        //Textarea autoresize
        $('textarea.auto-size').textareaAutoSize();
    };

    var _initStore = function() {
        storeUser = new Lawnchair({
            name: 'users',
            record: 'user'
        });

        storeNoti = new Lawnchair({
            name: 'notifications',
            record: 'notification'
        });

        storePlugin = new Lawnchair({
            name: 'apps',
            record: 'app'
        });
    };

    var _getContentAPI = function() {
        var deferred = Q.defer();
        var allJsonKeys = getAllJsonKeys();
        var getContent = "getContent";
        var postData = JSON.stringify({
            uid: user_id
        });

        var onSuccess = function(respData) {
            var data = JSON.parse(respData);

            if (data.resp) {
                var respCode = data.resp;
                if (respCode == 'A' || respCode == 'D' || respCode == 'AD' || respCode == 'L') {
                    swal({
                            title: "Oops",
                            text: "Your account has been expired. Please contact admin or mail us at <a href=" + mailToID + ">" + SUPPORT_EMAIL_ID + "</a>",
                            closeOnConfirm: true
                        },
                        function() {
                            _logout();
                        });
                }
                deferred.reject();
            } else {
                deferred.resolve(data);
                setJsonData('getContent', respData);
            }
        };
        startLoadingPageUI();
        //#TODO : This needs to be uncommented before publish
        var valPresent = jQuery.inArray(getContent, allJsonKeys)
        if (valPresent > -1) {
            var getContentData = getJsonData(getContent);
            onSuccess(getContentData);
            fnAjaxRequest(API_BASE_URL + 'getcontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            fnAjaxRequest(API_BASE_URL + 'getcontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }
        //var a = '{"module":[]}';
        //onSuccess(a);
        return deferred.promise;
    };

    var _fnLoadContent = function(cId, cType) {

        //var cType = $(this).data('type');
        //var cId = $(this).data('cid');
        $('#loaderIframeWebView').removeClass('hide');
        var timespent = _loadCatContent(cId, cType);

        $('#dvWebView').find('.aw-modal').removeClass('custom-home');
        $('#dvWebView').find('#dvModalHeader').removeClass('hide');


        $('#dvContentMeta').removeClass('hide');
        $('#dvContentThirdScreen').addClass('hide');

        //Open that popup
        $modal = $('#dvWebView');
        $overlay = $modal.next();
        $overlay.addClass('state-show');
        $modal.removeClass('state-leave').addClass('state-appear');
        $modal.find('.aw-modal-header').addClass('webview');

        $('#dvIframeContainer').addClass('hide');

        //Set parameters
        $('#dvModalHeader').data('mode', 'CONT');
        $('#dvModalHeader').data('cid', cId);
        $('#dvModalHeader').data('type', cType);

        //Reset status
        $('#btnBookmarkCont').data('bookmarkStatus', '0').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
        $('#btnLikeCont').data('likeStatus', '0').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');

        //Hide comment/recomm list
        $('#dvCommentList').addClass('hide');
        $('#dvRecommList').addClass('hide');

        $('.aw-modal-body').css('padding-bottom','0px');
        $('.aw-modal-body').css('height','calc(100% - 55px)');

        if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
            fireworks('aw-modal-aside-1', $('#' + 'aw-modal-aside-1').width(), $('#' + 'aw-modal-aside-1').height());
            fireworks('aw-modal-aside-2', $('#' + 'aw-modal-aside-2').width(), $('#' + 'aw-modal-aside-2').height());
        }
        return false;
    };

    var _fnLoadIcon = function (cId, cType, folderId) {

        localStorage.setItem("appMeta", getJsonData('appMeta'));
        localStorage.setItem("userData", getJsonData('userData'));

        if (cType == "action") {
            // var kbData = JSON.parse(localStorage.getItem("knowledgeBaseData")).knowledge_base;
            var kbData = JSON.parse(getJsonData('knowledgeBaseData')).knowledge_base;
            var kbActnData = kbData.action_button;
            var appObj = _.filter(kbActnData, {
                ab_id: cId.toString()
            });
            if(appObj == [] || appObj == undefined || appObj == ''){
                appObj = _.filter(kbActnData, {
                    ab_id: folderId.toString()
                });
                appObj = appObj[0].folder_data.icons;
                for (ico = 0; ico < appObj.length; ico++) {
                    //console.log(appObj[ico]);
                    if(appObj[ico].data.ab_id == cId.toString()){
                        appObj1 = appObj[ico].data;
                        appObj = [];
                        appObj.push(appObj1);
                    }
                }
            }
            var action = appObj[0].action;
            action = action.toLowerCase();
            let userData = JSON.parse(getJsonData('userData'));

            //package check
            switch (action.toLowerCase()) {
                case "localview":
                case "internalview":
                    {
                        if (appObj[0].sub_type.toLowerCase() === "plugin") {
                            //Code Here to change the screen
                            //icon
                            if (!fs.existsSync(__dirname + "/piz")) {
                                fs.mkdirSync(__dirname + "/piz");
                            }
                            var iconLink = appObj[0].img_xhdpi;
                            var pkgLink = appObj[0].action_url;
                            var appId = appObj[0].ab_id;
                            var pkgChkSum = appObj[0].plugin_version.package_checksum;
                            var appName = appObj[0].title;
                            var user_id = userData.uid;
                            var channel_id = userData.channel_id;
                            appResolution = appObj[0].plugin_version.screen_size;
                            appVersion = appObj[0].plugin_version.version_code;
                            destLocation = __dirname + "/piz/" + appId;
                            var fileLocation = __dirname + "/piz/" + appId + "/" + appVersion + ".zip";
                            varChkOpnPkg = 1;
                            var postData = JSON.stringify({
                                "type": "categoryAccessed",
                                "data": {
                                    "cat_id": "0",
                                    "uid": user_id,
                                    "channel_id": channel_id,
                                    "act_id": appId
                                }
                            });
                            clickedActionButton = appId;
                            globalPluginVersion = appVersion;
                            if (!fs.existsSync(destLocation)) {
                                fs.mkdirSync(destLocation);
                            }
                            if (!fs.existsSync(destLocation + "/" + appVersion)) {
                                fs.mkdirSync(destLocation + "/" + appVersion);
                            }
                            fnAjaxRequest(API_BASE_URL + 'GetCategoryContent.aspx', 'POST', {
                                Authorization: 'Bearer ' + base64String
                            }, {
                                abc: postData
                            }, onSuccess, onError);
                            var onSuccess = function (resp) {
                                alert("The data has been successfully updated");
                            }
                            var onError = function () {
                                alert("nahi challa");
                            }

                            downloadFile(pkgLink, destLocation + "/" + appVersion + ".zip", pkgChkSum, appName, iconLink);

                        }
                    }
                    break;
                case "webview":
                    {
                        appObj = appObj[0];
                        var action = appObj.action;
                        action = action.toLowerCase();

                        if (action == "webview") {
                            var srcurl = appObj.action_url;
                            var appHeight = parseInt($('html').css('height'));
                            var appWidth = parseInt($('html').css('width'));
                            appResolution = appObj.plugin_version.screen_size;

                            if (!(srcurl == "")) {
                                var appRes = appResolution;

                                if (appRes == undefined || appRes == null || appRes.min_width == null || appRes.max_width == null) {
                                    appRes = []
                                    appRes.min_width = appRes.max_width = 0;
                                }

                                if (parseInt(appRes.min_width) <= parseInt(appWidth)) {
                                    if (parseInt(appRes.max_width) > 0)
                                        appWidth = appRes.max_width;

                                    var closediv = document.createElement('div');
                                    var webview = document.createElement('webview');
                                    $(webview).attr("disablewebsecurity", "");
                                    $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
                                    $(closediv).attr('id', 'webview1');
                                    $(closediv).attr("align", "center");

                                    document.body.appendChild(closediv);
                                    var b = document.getElementById('webview1');

                                    $(webview).width(appWidth);
                                    $(webview).height("calc(" + appHeight + "px - 2.5rem)");
                                    webview.preload = __dirname + "/preload.js"
                                    webview.src = srcurl + "?dm_uid=" + userData.uid; //+"?dm_uid=";
                                    webview.useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"
                                    webview.addEventListener('dom-ready', () => {
                                        webview.openDevTools();
                                    });
                                    b.appendChild(webview);

                                    $('#create-home-screen').addClass('hide');
                                    timeStampStart = Math.round(+new Date() / 1000);
                                    $('#webview1').append('<div style="width:100%; position: fixed; bottom: 0; z-index: 9999;">' +
                                        '<div class="the-close-bar" style="width:100%">' +
                                        '<div class="closeTopTeamgumGumitBar closewala" style="width:100%; text-align:center;font-weight: 100; height:2.5rem; cursor:pointer; color:#fff;">CLOSE</div>' +
                                        '</div></div>');

                                    closeApp();
                                    return true;
                                } else {
                                    swal('', appRes.min_width_msg, 'error');
                                    $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
                                    $('#create-home-screen').removeClass('hide');
                                }
                            }
                            /* Need to ask first */
                            // else{
                            //     swal({
                            //         title: "",
                            //         text: errorMessage,
                            //         type: "success",
                            //         confirmButtonColor: "#28bc6a",
                            //         confirmButtonText: "Okay!",
                            //         closeOnConfirm: true
                            //     }, function() {
                            //         _logout();
                            //     }
                            // }
                        }
                    }
                    break;
                case "nativeview":
                    {
                        //var
                        if (os.platform().toLowerCase() === "win32") {
                            var regedit = require('regedit');
                            var linkToFindApps = "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths";
                            var result = "";
                            addInform = appObj[0];
                            addInform.plugin_version.native_data.registry_location = addInform.plugin_version.native_data.registry_location.replace('HKEY_LOCAL_MACHINE', 'HKLM');
                            regedit.list(addInform.plugin_version.native_data.registry_location, function (err, test) {
                                console.log(err);
                                if (err) {
                                    let shell = require('electron').shell;
                                    let isSuccessful = shell.openItem(appObj[0].action_url);
                                    if (isSuccessful == false) {
                                        isSuccessful = shell.openItem(addInform.plugin_version.native_data.download_url.windows_exe);
                                        if (isSuccessful == false)
                                            console.log('YOLO');
                                        else
                                            swal('', 'Kindly download the software from ' + addInform.plugin_version.native_data.download_url.windows_exe, 'error')
                                    }
                                } else {
                                    let fullPathWithExe = test[addInform.plugin_version.native_data.registry_location].values[""].value;
                                    let shell = require('electron').shell;
                                    let isSuccessful = shell.openItem(fullPathWithExe);
                                }
                            });
                        } else {
                            let shell = require('electron').shell;
                            let isSuccessful = shell.openItem(appObj[0].action_url);
                            console.log(isSuccessful);
                        }
                }
                    break;
            }

            if (appObj.length == 0) {
                return false;
            }
            appObj = appObj[0];
            var action = appObj.action;
            action = action.toLowerCase();
            if (action == "webview") {
                var srcurl = appObj.action_url;
                var appHeight = parseInt($('html').css('height'));
                var appWidth = parseInt($('html').css('width'));
                appResolution = appObj.plugin_version.screen_size;
                if (!(srcurl == "")) {
                    var appRes = appResolution;
                    if (appRes == undefined || appRes == null || appRes.min_width == null || appRes.max_width == null){
                        appRes = []
                        appRes.min_width = appRes.max_width = 0;
                    }

                    if (parseInt(appRes.min_width) <= parseInt(appWidth)) {
                        if (parseInt(appRes.max_width) > 0)
                            appWidth = appRes.max_width;

                        var closediv = document.createElement('div');
                        var webview = document.createElement('webview');
                        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
                        $(closediv).attr('id', 'webview1');
                        $(closediv).attr("align", "center");
                        document.body.appendChild(closediv);

                        var b = document.getElementById('webview1');
                        $(webview).width(appWidth);
                        $(webview).height(appHeight);
                        webview.src = srcurl+"?dm_uid="+userData.uid;
                        webview.useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"
                        webview.addEventListener('dom-ready', () => {
                            webview.openDevTools();
                        });
                        b.appendChild(webview);

                        $('#create-home-screen').addClass('hide');
                        timeStampStart = Math.round(+new Date() / 1000);
                        $('#webview1').append('<div style="width:100%; position: fixed; bottom: 0; z-index: 9999;">' +
                            '<div class="the-close-bar" style="width:100%">' +
                            '<div class="closeTopTeamgumGumitBar closewala" style="width:100%; text-align:center;font-weight: 100; height:2.5rem; cursor:pointer; color:#fff;">CLOSE</div>' +
                            '</div></div>');
                        closeApp();
                        return true;
                    } else {
                        swal('', appRes.min_width_msg, 'error');
                        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
                        $('#create-home-screen').removeClass('hide');
                    }
                }
            }
        }
        return false;
    };

    var _fnLoadCategory = function(cId, folderId) {
        //1open popup
        $('#dvModalHeader').addClass('hide');
        $('#loaderIframeWebView').removeClass('hide');
        $("#dvContentListContainer").removeClass('hide');
        $("#dvContentListContainer").css("height", "100%");
        $('.aw-modal-body').append('<div style="width:100% position: fixed; bottom: 0; z-index: 9999;" class="hideTheCloseBar">' +
            '<div class="the-close-bar" style="width:100%">' +
            '<div class="closeTopTeamgumGumitBar closewalaCMS" style="width:100%; text-align:center;font-weight: 100; height:2.5rem; color: #fff; cursor:pointer;">CLOSE</div>' +
            '</div></div>');

        var timespent = _loadCatDetail(cId, true);

        $('#dvWebView').find('.aw-modal').removeClass('custom-home');
       // $('#dvWebView').find('#dvModalHeader').removeClass('hide');

        //Open that popup
        $modal = $('#dvWebView');
        $overlay = $modal.next();
        $overlay.addClass('state-show');
        $modal.removeClass('state-leave').addClass('state-appear');
        $modal.find('.aw-modal-header').addClass('webview');

        $('#dvIframeContainer').addClass('hide');



        //Hide comment/recomm list
        $('#dvCommentList').addClass('hide');
        $('#dvRecommList').addClass('hide');

        if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
            fireworks('aw-modal-aside-1', $('#' + 'aw-modal-aside-1').width(), $('#' + 'aw-modal-aside-1').height());
            fireworks('aw-modal-aside-2', $('#' + 'aw-modal-aside-2').width(), $('#' + 'aw-modal-aside-2').height());
        }
        $('.aw-modal-body').css('padding-bottom','0');
        $('.aw-modal').css('padding-bottom','1.54em');
        //show existing content cards in popup
        return false;
    };

    var startLoadingPageUI = function() {
        brandName = localStorage.getItem("BrandName") || "Drona";
        brandImage = localStorage.getItem("BrandImage") || "";

        $('.brand-image').attr("src", brandImage);
        $('.Brand-name').html(brandName);
        var test = getJsonData('knowledgeBaseData');
        if (test === undefined) {
            $('#dvIframeContainer').addClass("hide");
            $('#LoaderScreen').removeClass("hide");
        }
        //Configure Screen Animation
        setTimeout(function() {
            $(".determinate").css("width", "50%");
        }, 300);

        setTimeout(function() {
            $(".determinate").css("width", "90%");
        }, 3000);
    }

    var stopLoadingPageUI = function() {
        $(".determinate").css("width", "100%");
        setTimeout(function() {
            $('#LoaderScreen').addClass("hide");
            $('#dvIframeContainer').removeClass("hide");
        }, 3000);
    }

    return {
        init: function() {

            //Intialize DB Store
            _initStore();
            authToken();
            _initUser();
            _initPlugins();

            //Show loading.

            //startPageBlock();
            _onEvent();

            /* GetContent.aspx */
            _getContentAPI().then(function(data) {
                var unreadCount = data.module.length;
                var firstmodule = data.module[0];

                storeUser.save({
                    key: 'unread-inbox',
                    data: unreadCount
                });

                storeUser.save({
                    key: 'show-flash',
                    data: firstmodule
                });

                //Send event to cordova webview for custom home to consume
                if (objCordovaWebView) {
                    objCordovaWebView.fireDocumentEvent('dronahq.app.getbadge', unreadCount);
                    objCordovaWebView.fireDocumentEvent('dronahq.app.showflash', firstmodule);
                }
            });

            /* in background we need to check if this account has a custom homescreen or not.*/
            _loadAppList().then(function(data) {
                //Got all data
                stopLoadingPageUI();
                //if(ckhKBSame )
                //stopPageBlock();
                var objKB = data.knowledge_base;

                var arrHome = _.filter(objKB.action_button, {
                    action: 'internalview',
                    plugin_version: {
                        open_code: 'homescreen'
                    }
                });

                if (arrHome.length > 0) {
                    //Custom Homescreen possible                
                    var webUrl = arrHome[0].plugin_version.web_url;
                    if (webUrl && webUrl.length > 0) {
                        _awesomeModal(true);
                        _makeCustomHomePopup();
                        _webViewPopup(webUrl, false, true, arrHome[0].ab_id);
                        return;
                    }
                }

                _awesomeModal(true);
                _makeCustomHomePopup();
                if (NewHomeScreenOpened == 1)
                    _webViewPopup(__dirname + '/custom-home/index.html', false, true, 'cust');
                else
                    _webViewPopup(destLocation + "/" + appVersion + "/index.html", false, true, 'cust');

                return;
                var arrActionBtn = data.knowledge_base.action_button;
                var arrCategory = data.knowledge_base.category;
                //MERGE arrActionBtn AND arrCategory SORTED WRT DISPLAY INDEX
                //for every item[i] in arrCategory
                //compare it's display index value[a] with display index value[b] for every item[j] in arrActionBtn
                //if(a < b) => insertPos := j
                //add item[i] of arrCategory in position j of arrActionBtn
                for (var i = 0; i < arrCategory.length; i++) {
                    var closestLargestPos = 99999999;
                    for (var j = 0; j < arrActionBtn.length; j++) {
                        if ((arrActionBtn[j].action_display_index) || (arrActionBtn[j].cat_disp_order)) {
                            if ((+arrCategory[i].cat_disp_order < +arrActionBtn[j].action_display_index) || (+arrCategory[i].cat_disp_order < +arrActionBtn[j].cat_disp_order)) {
                                if (closestLargestPos > j) {
                                    closestLargestPos = j;
                                }
                            }
                        }
                    }
                    arrActionBtn.splice(closestLargestPos, 0, arrCategory[i]);
                }
                var tempData = {
                    action_button: arrActionBtn
                }
                var HTML = fnHandlebarTemplate('template-app-list', tempData);

                $('#uListAppList').append(HTML);

                //Continue as always
                $('#dvMainSection').removeClass('hide');
                _defaultview();
                _awesomeModal();
                _fnApplyAppMeta();
                if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
                    fireworks('aw-modal-aside-1', $('#' + 'aw-modal-aside-1').width(), $('#' + 'aw-modal-aside-1').height());
                    fireworks('aw-modal-aside-2', $('#' + 'aw-modal-aside-2').width(), $('#' + 'aw-modal-aside-2').height());
                }
            }, function(err) {
                //Resp error
            });
            /* CHECK IF THERE IS ANY UPDATE AVAILABLE */
            callCheckForUpdate();
        },

        closeAwesomeModal: function() {
            _fnActualCloseModal();
        },

        loadInbox: function() {
            $("#inbox").trigger('click');
        },

        loadContent: function(destId, destType) {
            _fnLoadContent(destId, destType);
        },

        logout: function() {
            _logout(true);
        },

        loadIcon: function(destId, destType, folderId) {
            _fnLoadIcon(destId, destType, folderId);
        },

        loadCategory: function(destId, folderId) {
            _fnLoadCategory(destId, folderId);
        },

        fetchKnowledgeBase: function() {
            return _loadAppList();
        },

        fetchInbox: function(_maxInboxId, _maxInboxResult, searchText, filterType) {
            return _loadInboxData(_maxInboxId, _maxInboxResult, searchText, filterType);
        },

        getCommentList: function(contentId) {
            return _loadCommentlist(contentId);
        },

        setLike: function(contentId, likeStatus) {
            return _addlike(contentId, likeStatus);
        },

        getLikeList: function(contentId) {
            return _loadlikelist(contentId);
        },

        setBookmark: function(contentId, bkmrkStatus) {
            return _addbkmrk(contentId, bkmrkStatus);
        },

        getAllBookmarks: function() {
            return _getbkmrks();
        },

        addComment: function(contentId, userComment) {
            return _addcomment(contentId, userComment);
        },

        deleteInboxEntry: function(inboxId) {
            return _delInboxEntry(inboxId);
        },

        setAppRating: function(appRating) {
            return _fnSetRating(appRating);
        },

        handleMedia: function(mediaUrl, mediaType) {
            return _handleTheMedia(mediaUrl, mediaType);
        },
        resetBadge: function() {
            return _resetBadge();
        },

        SetFavouriteApps: function (FavouritesJson) {
            return _setFavouriteApps(FavouritesJson);
        }
    }
};