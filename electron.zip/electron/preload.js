var DEVICE_ID             = "0000000000";
var DEVICE_TYPE           = "Electron";
var APP_NAME              = "DronaHQ";
var OAUTH_CLIENT_ID       = 'a';
var OAUTH_CLIENT_SECRET   = 'd';
var API_BASE_URL          = 'https://api.dronamobile.com/interface/v3/';
var DECRYPTION_KEY        = "a";
var CHANNEL_NAME          = "";
var APP_VERSION           = "0.0.1";
var SUPPORT_EMAIL_ID      = "Friends@dronamobile.com";
var destLocation          = "";
var appVersion            = "";
var timeStampStart        = "";
var timeStampEnd          = "";
var timeStampMainAppStart = "";
var timeStampMainAppEnd   = "";
var base64String          = "";
var clickedActionButton   = "";
var globalPluginVersion   = "";
var appResolution         = "";
var isLoggedIn            = "";


var checker = 0;
'use strict';

var Lawnchair             = require("lawnchair");
var EJstorage             = require('electron-json-storage-sync');
var fs                    = require('fs');
var request               = require('request');
var AdmZip                = require('adm-zip');
// var RNCryptor             = require('jscryptor');
var md5File               = require('md5-file');
var checksum              = require('checksum');
var Q                     = require('Q');
// var notify                = require('electron-notification')
var pkgChkSumNew          = "";
var varChkOpnPkg          = 0;
var NewHomeScreenOpened   = 0;
var chkSumCounter         = 0;
var mailToID              = "mailTo:" + SUPPORT_EMAIL_ID;
var ckhKBSame             = 0;
isLoggedIn                = 1;
var {ipcRenderer, remote} = require('electron');  
var main                  = remote.require("./main.js");
var objCordovaWebView;
var out, dl;

var CordovaWebview = function () {
    var $cordovaIFrame,
        objCmdMap;

    var storeUser, storeNoti, storeKV;

    var CommandMap = function () {
        // internal map of proxy function
        var CommandProxyMap = {};
        return {
            add: function (id, proxyObj) {
                CommandProxyMap[id] = proxyObj;
                return proxyObj;
            },

            remove: function (id) {
                var proxy = CommandProxyMap[id];
                delete CommandProxyMap[id];
                CommandProxyMap[id] = null;
                return proxy;
            },

            get: function (service, action) {
                return (CommandProxyMap[service] ? CommandProxyMap[service][action] : null);
            },

            clear: function () {
                CommandProxyMap = {};
            }
        }
    };

    var pluginDevice = function () {
        function getPlatform() {
            var os = require('os');
            //If windows
            if(os.type() === "Windows_NT")
                {
                    //For windows 10
                    if(parseInt(os.release()) >= 9)
                            return("Windows 10");
                    //For windows 8 and 8.1
                    else if(parseInt(os.release())>=6 && parseInt(os.release())<8)
                            return("Windows 8");
                    //For windows 7
                    else if(parseInt(os.release()>=5 && parseInt(os.release()<6)))
                            return("Windows 7");
                }
                else if(os.type() === "Darwin")
                    return "Mac";
                else
                return "Linux";
        }

        function getModel() {
            return getBrowserInfo(true);
        }

        function getVersion() {
            return getBrowserInfo(false);
        }

        function getBrowserInfo(getModel) {
            //var userAgent = navigator.userAgent;
            var returnVal = '';
            var offset;
            switch (navigator.platform.toLowerCase()) {
                case "win32":
                    {
                        var os = require('os');
                        //If windows
                        if (os.type() === "Windows_NT") {
                            //For windows 10
                            if (parseInt(os.release()) >= 9)
                                return ("Windows 10");
                            //For windows 8 and 8.1
                            else if (parseInt(os.release()) >= 6 && parseInt(os.release()) < 8)
                                return ("Windows 8");
                            //For windows 7
                            else if (parseInt(os.release() >= 5 && parseInt(os.release() < 6)))
                                return ("Windows 7");
                        }
                        break;
                    }
                case "macintel":
                    {
                        return ("Mac");
                        break;
                    }
            }
        }

        var getDeviceInfo = function (success, error) {
            setTimeout(function () {
                success({
                    cordova: 'NA',
                    platform: getPlatform(),
                    model: getModel(),
                    version: getVersion(),
                    uuid: null
                });
            }, 0);

        }

        return {
            getDeviceInfo: getDeviceInfo
        };
    };

    var pluginInAppBrowser = function () {
        var browserWrap,
            popup,
            navigationButtonsDiv,
            navigationButtonsDivInner,
            backButton,
            forwardButton,
            closeButton;

        function attachNavigationEvents(element, callback) {
            var onError = function () {
                callback({
                    type: "loaderror",
                    url: this.contentWindow.location
                }, {
                    keepCallback: true
                });
            };

            element.addEventListener("pageshow", function () {
                callback({
                    type: "loadstart",
                    url: this.contentWindow.location
                }, {
                    keepCallback: true
                });
            });

            element.addEventListener("load", function () {
                callback({
                    type: "loadstop",
                    url: this.contentWindow.location
                }, {
                    keepCallback: true
                });
            });

            element.addEventListener("error", onError);
            element.addEventListener("abort", onError);
        }

        var IAB = {
            close: function (win, lose) {
                if (browserWrap) {
                    if (win) win({
                        type: "exit"
                    });

                    browserWrap.parentNode.removeChild(browserWrap);
                    browserWrap = null;
                    popup = null;
                }
            },

            show: function (win, lose) {
                if (browserWrap) {
                    browserWrap.style.display = "block";
                }
            },

            open: function (win, lose, args) {
                var strUrl = args[0],
                    target = args[1],
                    features = args[2],
                    url;

                window.open(strUrl);
                return;

                if (target === "_system" || target === "_self" || !target) {
                    window.location = strUrl;
                } else {
                    // "_blank" or anything else
                    if (!browserWrap) {
                        browserWrap = document.createElement("div");
                        browserWrap.style.position = "absolute";
                        browserWrap.style.borderWidth = "40px";
                        browserWrap.style.width = "calc(100% - 80px)";
                        browserWrap.style.height = "calc(100% - 80px)";
                        browserWrap.style.borderStyle = "solid";
                        browserWrap.style.borderColor = "rgba(0,0,0,0.25)";

                        browserWrap.onclick = function () {
                            setTimeout(function () {
                                IAB.close(win);
                            }, 0);
                        };

                        document.body.appendChild(browserWrap);
                    }

                    if (features.indexOf("hidden=yes") !== -1) {
                        browserWrap.style.display = "none";
                    }

                    popup = document.createElement("iframe");
                    popup.style.borderWidth = "0px";
                    popup.style.width = "100%";

                    browserWrap.appendChild(popup);

                    if (features.indexOf("location=yes") !== -1 || features.indexOf("location") === -1) {
                        popup.style.height = "calc(100% - 60px)";

                        navigationButtonsDiv = document.createElement("div");
                        navigationButtonsDiv.style.height = "60px";
                        navigationButtonsDiv.style.backgroundColor = "#404040";
                        navigationButtonsDiv.style.zIndex = "999";
                        navigationButtonsDiv.onclick = function (e) {
                            e.cancelBubble = true;
                        };

                        navigationButtonsDivInner = document.createElement("div");
                        navigationButtonsDivInner.style.paddingTop = "10px";
                        navigationButtonsDivInner.style.height = "50px";
                        navigationButtonsDivInner.style.width = "160px";
                        navigationButtonsDivInner.style.margin = "0 auto";
                        navigationButtonsDivInner.style.backgroundColor = "#404040";
                        navigationButtonsDivInner.style.zIndex = "999";
                        navigationButtonsDivInner.onclick = function (e) {
                            e.cancelBubble = true;
                        };


                        backButton = document.createElement("button");
                        backButton.style.width = "40px";
                        backButton.style.height = "40px";
                        backButton.style.borderRadius = "40px";

                        backButton.innerHTML = "←";
                        backButton.addEventListener("click", function (e) {
                            if (popup.canGoBack)
                                popup.goBack();
                        });

                        forwardButton = document.createElement("button");
                        forwardButton.style.marginLeft = "20px";
                        forwardButton.style.width = "40px";
                        forwardButton.style.height = "40px";
                        forwardButton.style.borderRadius = "40px";

                        forwardButton.innerHTML = "→";
                        forwardButton.addEventListener("click", function (e) {
                            if (popup.canGoForward)
                                popup.goForward();
                        });

                        closeButton = document.createElement("button");
                        closeButton.style.marginLeft = "20px";
                        closeButton.style.width = "40px";
                        closeButton.style.height = "40px";
                        closeButton.style.borderRadius = "40px";

                        closeButton.innerHTML = "✖";
                        closeButton.addEventListener("click", function (e) {
                            setTimeout(function () {
                                IAB.close(win);
                            }, 0);
                        });

                        // iframe navigation is not yet supported
                        backButton.disabled = true;
                        forwardButton.disabled = true;

                        navigationButtonsDivInner.appendChild(backButton);
                        navigationButtonsDivInner.appendChild(forwardButton);
                        navigationButtonsDivInner.appendChild(closeButton);
                        navigationButtonsDiv.appendChild(navigationButtonsDivInner);

                        browserWrap.appendChild(navigationButtonsDiv);
                    } else {
                        popup.style.height = "100%";
                    }

                    // start listening for navigation events
                    attachNavigationEvents(popup, win);

                    popup.src = strUrl;
                }
            },

            injectScriptCode: function (win, fail, args) {
                var code = args[0],
                    hasCallback = args[1];

                if (browserWrap && popup) {
                    try {
                        popup.contentWindow.eval(code);
                        hasCallback && win([]);
                    } catch (e) {
                        console.error('Error occured while trying to injectScriptCode: ' + JSON.stringify(e));
                    }
                }
            },

            injectScriptFile: function (win, fail, args) {
                var msg = 'Browser cordova-plugin-inappbrowser injectScriptFile is not yet implemented';
                console.warn(msg);
                fail && fail(msg);
            },

            injectStyleCode: function (win, fail, args) {
                var msg = 'Browser cordova-plugin-inappbrowser injectStyleCode is not yet implemented';
                console.warn(msg);
                fail && fail(msg);
            },

            injectStyleFile: function (win, fail, args) {
                var msg = 'Browser cordova-plugin-inappbrowser injectStyleFile is not yet implemented';
                console.warn(msg);
                fail && fail(msg);
            }
        };


        return IAB;
    };

    var pluginDronaHQ = function () {

        //Init store that will be used for DBContext
        storeUser = new Lawnchair({
            name: 'users',
            record: 'user'
        });

        storeNoti = new Lawnchair({
            name: 'notifications',
            record: 'notification'
        });

        var DronaHQ = {
            getUserProfile: function (success, fail) {
                storeUser.get('uinfo', function (data) {
                    var objUser = {
                        "uid": "1",
                        "user_name": "Smurf Pandeyq",
                        "user_email": "neeraj@dronamobile.com",
                        "user_group": "Default",
                        "user_desig": "Genin",
                        "user_profile_image": "https://dronamobilepublic.s3.amazonaws.com/Smurfville/user/profile/raBc59i.jpeg",
                        "user_curr_country": "",
                        "user_curr_city": "",
                        "user_about": "",
                        "channel_id": "3",
                        "readonly": "0"
                    }
                    success({
                        uid: objUser.uid,
                        name: objUser.user_name,
                        designation: objUser.user_desig,
                        email: objUser.user_email,
                        profile_image: objUser.user_profile_image,
                        nonce: "Thisistest" /*TODO HARDCODE THIS MWAHAHAHAHAHZAHAHAHAHAH*/
                    });
                });
            },

            getNotification: function (success, fail, args) {
                var notiId = parseInt(args[0], 10);

                if (isNaN(notiId) || notiId < 1) {
                    //Invalid notiId
                    fail && fail({
                        code: 1,
                        reason: 'Invalid notification id'
                    });
                    return;
                }

                //blah blah
                storeNoti.get('noti-' + notiId, function (data) {
                    var appNotiData = data.data;
                    success(appNotiData);
                });
            },

            getAllNotification: function (success, fail, args) {

            },

            exitApp: function () {
                //Close the iframe
                _appId = 0;
                window.objDronaHQ.closeAwesomeModal();
                //closeApp();
                ipcRenderer.send('async', "ExitAppMwahahahaha");
            },

            getApplicationDetails: function (success, fail) {
                //var objAppMeta = JSON.parse(localStorage.getItem('appMeta'));
                var objAppMeta = JSON.parse(getJsonData('appMeta'));
                storeUser.get('unread-inbox', function (data) {
                    var unreadCount = data.data;

                    var objResp = {
                        app_name: 'DronaHQ',
                        app_version: '0.0',
                        branding: {
                            topbar_logo: objAppMeta.top_bar_icon.img_xhdpi,
                            topbar_text: objAppMeta.top_bar_text
                        },
                        inbox_badge: unreadCount
                    }

                    success(objResp);
                });


            },

            navigation: function (success, fail, args) {
                var destination = args[0];

                var support = 'http://www.dronahq.com/newticket';

                switch (destination) {
                    case "about": {
                        // swal("About Us", "This app optimises sales users engagement with externally sourced customer information when preparing for client meetings. The application acts as a ‘one-stop shop’ where sales people can access the most relevant and up-to-date external sources of customer data, tailored to their personal needs and profile.");
                        return;
                    }
                    case "support": {
                        window.open(support);
                        return;
                    }
                    case "inbox": {
                        // Hide the custom popup
                        var $modal = $('.aw-modal-frame');
                        var $overlay = $('.aw-modal-overlay');
                        $overlay.removeClass('state-show');
                        $modal.removeClass('state-appear').addClass('state-leave');

                        // Hide the iframe too
                        $('#frmCustomHome').addClass('hide');

                        // Show the inbox 
                        $('#dvMainSection').removeClass('hide');

                        // Load the inbox
                        window.objDronaHQ.loadInbox();
                        return;
                    }
                    case "logout": {
                        window.objDronaHQ.logout();
                        return;
                    }
                    case "content": {
                        window.objDronaHQ.loadContent(args[1], args[2]);
                        return;
                    }
                    case "icon": {
                        if (args[2] == "action")
                            window.objDronaHQ.loadIcon(args[1], args[2], args[3]);
                        else if (args[2] == "category")
                            window.objDronaHQ.loadCategory(args[1], args[3]);
                        return;
                    }
                }
            },

            getHomeScreenIcons: function (success, fail, args) {
                //var kbData = localStorage.getItem("knowledgeBaseData");
                var kbData = getJsonData('knowledgeBaseData');
                if (kbData == null || kbData == undefined) {
                    //fetch data from server else
                    window.objDronaHQ.fetchKnowledgeBase().then(function (value) {
                        success(value);
                    }, function (e) {
                        fail(e);
                    });
                    //return success
                } else {
                    var kbDataObj = JSON.parse(kbData).knowledge_base;
                    var kbDataCat = kbDataObj.category;
                    var kbDataActnBtn = kbDataObj.action_button;
                    var kbDataCatListType = kbDataObj.cat_list_type;
                    var kbArr = [];
                    var index = 0;
                    for (var i = 0; i < kbDataCat.length; i++) {
                        var object = {};
                        object.dispay_order = kbDataCat[i].cat_disp_order;
                        object.icon_img = kbDataCat[i].cat_img_url;
                        object.id = kbDataCat[i].cat_id;
                        //object.is_new = kbDataCat[i].;
                        object.my_fav = kbDataCat[i].my_fav;
                        object.title = kbDataCat[i].cat_name;
                        object.type = "category";
                        kbArr[index] = object;
                        index++;
                    }
                    for (var i = 0; i < kbDataActnBtn.length; i++) {
                        var object = {};
                        if (kbDataActnBtn[i].action == "folderview") {
                            object.type = "folderview";
                            var folderDataIcons = kbDataActnBtn[i].folder_data.icons;
                            var folderIcons = [];
                            for (var j = 0; j < folderDataIcons.length; j++) {
                                var icon = {};
                                icon.dispay_order = folderDataIcons[j].data.action_display_index;
                                icon.icon_img = folderDataIcons[j].data.image_url;
                                icon.id = folderDataIcons[j].data.ab_id;
                                icon.my_fav = folderDataIcons[j].data.my_fav;
                                icon.title = folderDataIcons[j].data.title;
                                if (folderDataIcons[j].type == "ACTION") {
                                    icon.type = "action_button";
                                } else {
                                    icon.type = "category";
                                }
                                folderIcons[index] = icon;
                                j++;
                            }
                            object.icons = folderIcons;
                        } else {
                            //object.is_new = kbDataCat[i].;
                            object.type = "action_button";
                        }
                        object.dispay_order = kbDataActnBtn[i].action_display_index;
                        object.icon_img = kbDataActnBtn[i].image_url;
                        object.id = kbDataActnBtn[i].ab_id;
                        object.my_fav = kbDataActnBtn[i].my_fav;
                        object.title = kbDataActnBtn[i].title;
                        kbArr[index] = object;
                        index++;
                    }
                    var kbDataJson = JSON.stringify(kbArr),
                        kbDataRet = {};
                    kbDataRet.icons = kbArr;
                    success(kbDataRet);
                }

            },

            //create getinbox idhar dronahq se call hoga wo call karega to dronaapppage

            getInbox: function (success, fail, args) {
                var _maxInboxId = args[0];
                var _maxInboxResult = args[1];
                var searchText = args[2];
                var filterType = args[3];

                window.objDronaHQ.fetchInbox(_maxInboxId, _maxInboxResult, searchText, filterType).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });

                //var user_id = args[0];
                //var base64String = args[3];
                //function onSuccess(respdata) {
                //    var data = JSON.parse(respdata);
                //    if (data.moduleInbox) {

                //        var arrAppNoti = _.filter(data.moduleInbox, { content_json: { sub_type: 'app_noti' } });

                //        _.forEach(arrAppNoti, function (objModule) {
                //            var objNotiData = objModule.content_json.noti_data;
                //            var appData = objNotiData.app_data;

                //            if (appData) {
                //                storeNoti.save({
                //                    key: 'noti-' + objNotiData.noti_id,
                //                    data: JSON.parse(appData)
                //                });
                //            }
                //        });
                //        success(data);
                //    } else if (data.resp) {
                //        var errorCode = data.resp;
                //        if (errorCode == 0) {
                //            swal('Oops!', 'Server error!', 'error');
                //        }
                //        else if (errorCode == 1) {
                //            swal('Oops!', 'Invalid request', 'error');
                //        }
                //        else if (errorCode == 2) {
                //            var $tempNoCategoryDetailMsg = $('#tempNoNotificationsMsg').clone().removeClass('hide');
                //            $('#noti-container').html('');
                //            $('#noti-container').html($tempNoCategoryDetailMsg);
                //        }
                //    }
                //}

                //var postData = JSON.stringify({ uid: user_id, inbox_id: _maxInboxId, inbox_count: _maxInboxResult, search_text: searchText, filter_type: filterType });

                //fnAjaxRequest(apiBaseUrl + 'contentinbox.aspx', 'POST', { Authorization: 'Bearer ' + base64String }, { abc: postData }, onSuccess, onError);
            },

            getAllUserCommentList: function (success, fail, args) {
                var contentId = args[0];
                window.objDronaHQ.getCommentList(contentId).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            setUserLike: function (success, fail, args) {
                var contentId = args[0];
                var likeStatus = args[1];
                window.objDronaHQ.setLike(contentId, likeStatus).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            getAllUserLikeList: function (success, fail, args) {
                var contentId = args[0];
                window.objDronaHQ.getLikeList(contentId).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            setUserBookmark: function (success, fail, args) {
                var contentId = args[0];
                var bkmrkStatus = args[1];
                window.objDronaHQ.setBookmark(contentId, bkmrkStatus).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            getAllUserBoommarks: function (success, fail, args) {
                window.objDronaHQ.getAllBookmarks().then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            setUserComment: function (success, fail, args) {
                var contentId = args[0];
                var userComment = args[1];
                window.objDronaHQ.addComment(contentId, userComment).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            deleteInbox: function (success, fail, args) {
                var inboxId = args[0];
                window.objDronaHQ.deleteInboxEntry(inboxId).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            setAppRating: function (success, fail, args) {
                var appRating = args[0];
                window.objDronaHQ.setAppRating(appRating).then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                });
            },

            handleMedia: function (success, fail, args) {
                var mediaUrl = args[0];
                var mediaType = args[1];
                window.objDronaHQ.handleMedia(mediaUrl, mediaType).then(function (value) {
                    succecss(value);
                }, function (e) {
                    fail(e);
                })
            },

            resetBadge: function (success, fail, args) {
                window.objDronaHQ.resetBadge().then(function (value) {
                    success(value);
                }, function (e) {
                    fail(e);
                })
            }
        };

        return DronaHQ;
    };

    var pluginDHQStorage = function () {

        storeKV = new Lawnchair({
            name: 'kv-store',
            record: 'key'
        });

        var _getKeyName = function (keyName) {
            return 'app-' + _appId + '-' + keyName;
        }

        var _getKeyName_Global = function (keyName) {
            return 'app-G-' + keyName;
        }


        var DHQStorage = {
            get: function (success, fail, args) {
                var keyName = args[0];

                var isExists = storeKV.exists(_getKeyName(keyName), function (itDoes) {
                    if (itDoes) {
                        storeKV.get(_getKeyName(keyName), function (data) {
                            var appNotiData = data.data;
                            success(appNotiData);
                        });
                    } else {
                        // Check in global store
                        storeKV.exists(_getKeyName_Global(keyName), function (itDoes) {
                            if (itDoes) {
                                storeKV.get(_getKeyName_Global(keyName), function (data) {
                                    var appNotiData = data.data;
                                    success(appNotiData);
                                });
                            } else {
                                fail({
                                    "error_message": "No value present"
                                });
                            }
                        });
                    }
                });

            },

            set: function (success, fail, args) {
                var keyName = args[0];
                var keyValue = args[1];

                var isGlobal = 0;
                if (args.length > 2) {
                    isGlobal = args[2];
                }

                if (!isGlobal) {
                    storeKV.save({
                        key: _getKeyName(keyName),
                        data: keyValue
                    });
                } else {
                    // Store as global variable
                    storeKV.save({
                        key: _getKeyName_Global(keyName),
                        data: keyValue
                    });
                }

                success({
                    value: 'Value saved successfully'
                });
            },

            remove: function (success, fail, args) {
                var keyName = args[0];

                storeKV.remove(_getKeyName(keyName));
                success({
                    value: 'Value removed sucussfully'
                });
            },

            clearAll: function (success, fail, args) {
                // Get All keys starting with app-appId-* remove

                // get all the keys
                storeKV.keys(function (keys) {
                    keys.forEach(function (val) {
                        if (val.indexOf('app-' + _appId + '-') === 0) {
                            // Remove this key
                            storeKV.remove(val);
                        }
                    })
                })
            }
        };
        return DHQStorage;
    };

    var pluginCamera = function () {
        /*
         *
         * Licensed to the Apache Software Foundation (ASF) under one
         * or more contributor license agreements.  See the NOTICE file
         * distributed with this work for additional information
         * regarding copyright ownership.  The ASF licenses this file
         * to you under the Apache License, Version 2.0 (the
         * "License"); you may not use this file except in compliance
         * with the License.  You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing,
         * software distributed under the License is distributed on an
         * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
         * KIND, either express or implied.  See the License for the
         * specific language governing permissions and limitations
         * under the License.
         *
         */

        function takePicture(success, error, opts) {
            if (opts && opts[2] === 1) {
                capture(success, error);
            } else {
                var input = document.createElement('input');
                input.type = 'file';
                input.name = 'files[]';

                input.onchange = function (inputEvent) {
                    var canvas = document.createElement('canvas');

                    var reader = new FileReader();
                    reader.onload = function (readerEvent) {
                        input.parentNode.removeChild(input);

                        var imageData = readerEvent.target.result;

                        return success(imageData.substr(imageData.indexOf(',') + 1));
                    }

                    reader.readAsDataURL(inputEvent.target.files[0]);
                };

                document.body.appendChild(input);
            }
        }

        function capture(success, errorCallback) {
            var localMediaStream;

            var video = document.createElement('video');
            var button = document.createElement('button');

            video.width = 320;
            video.height = 240;
            button.innerHTML = 'Capture!';

            button.onclick = function () {
                // create a canvas and capture a frame from video stream
                var canvas = document.createElement('canvas');
                canvas.getContext('2d').drawImage(video, 0, 0, 320, 240);

                // convert image stored in canvas to base64 encoded image
                var imageData = canvas.toDataURL('img/png');
                imageData = imageData.replace('data:image/png;base64,', '');

                // stop video stream, remove video and button
                localMediaStream.stop();
                video.parentNode.removeChild(video);
                button.parentNode.removeChild(button);

                return success(imageData);
            }

            navigator.getUserMedia = navigator.getUserMedia ||
                                     navigator.webkitGetUserMedia ||
                                     navigator.mozGetUserMedia ||
                                     navigator.msGetUserMedia;

            var successCallback = function (stream) {
                localMediaStream = stream;
                video.src = window.URL.createObjectURL(localMediaStream);
                video.play();

                document.body.appendChild(video);
                document.body.appendChild(button);
            }

            if (navigator.getUserMedia) {
                navigator.getUserMedia({
                    video: true,
                    audio: true
                }, successCallback, errorCallback);
            } else {
                alert('Browser does not support camera :(');
            }
        }

        var Camera = {
            takePicture: takePicture,
            cleanup: function () {}
        }

        return Camera;
    };

    var pluginLocalNoti = function () {
        var LocalNoti = {
            deviceready: function () {}
        }
        // notify('', {
        //     body: 'The body of the notification'
        // }, () => {
        //     console.log('Notification was clicked!')
        // })
        return LocalNoti;
    };

    var createNotification = function(){
        
    }

    var pluginSQLite = function () {

        var _fnExecuteSql = function (dbName, queryList, success) {

            var yoloDb = window.openDatabase(dbName, '1.0', 'DHQ DB', 5 * 1024 * 1024);

            var batchResult = [];

            var fnExecuteTrans = function (tx) {
                if (queryList.length === 0) {
                    success(batchResult);
                    return;
                }

                var thisQuery = queryList.shift();

                if (thisQuery.sql.indexOf('BEGIN') !== 0) {
                    tx.executeSql(thisQuery.sql, thisQuery.params, function (xtx, results) {

                        var rows = {};
                        var length = results.rows.length;
                        for (var i = 0; i < length; i++) {
                            rows[i] = results.rows.item(i);
                        }

                        batchResult.push({
                            result: {
                                rows: rows
                            },
                            type: 'success'
                        });
                        fnExecuteTrans(tx);
                    });
                } else {
                    fnExecuteTrans(tx);
                }
            };

            yoloDb.transaction(function (tx) {
                fnExecuteTrans(tx);
            });
        };

        var SQLite = {
            open: function (success, fail, args) {
                if (!window.openDatabase) {
                    console.error('SQLite is not supported on this browser.');
                    return;
                }

                var dbName = args[0].name;

                var yoloDb = window.openDatabase(dbName, '1.0', 'DHQ DB', 5 * 1024 * 1024);
                success();
            },
            close: function (success, fail, args) {
                console.warn('Method not supported by Websql');
            },
            echoStringValue: function (success, fail, args) {

            },
            delete: function (success, fail, args) {
                console.warn('Method not supported by Websql');
            },
            executeSqlBatch: function (success, fail, args) {
                var dbName = args[0].dbargs.dbname;
                var queryList = args[0].executes;
                _fnExecuteSql(dbName, queryList, success);
            },
            backgroundExecuteSqlBatch: function (success, fail, args) {
                var dbName = args[0].dbargs.dbname;
                var queryList = args[0].executes;
                _fnExecuteSql(dbName, queryList, success);
            }
        }

        return SQLite;
    };

    var pluginConnInfo = function () {

        var Connection = {
            UNKNOWN: "unknown",
            ETHERNET: "ethernet",
            WIFI: "wifi",
            CELL_2G: "2g",
            CELL_3G: "3g",
            CELL_4G: "4g",
            CELL: "cellular",
            NONE: "none"
        };

        var type = navigator.onLine ? Connection.UNKNOWN : Connection.NONE;

        return {
            getConnectionInfo: function (cbSuccess) {
                // force async
                setTimeout(function () {
                    cbSuccess(type);
                }, 0);
            }
        };
    };

    var getfilePath = function () {
        var fs = require('fs');

        return {
            requestAllPaths: function (filePath) {

                setTimeout(function () {
                    filePath(__dirname);
                }, 0);
            },

            requestFileSystem: function (filePath) {

                setTimeout(function () {

                    fs.readdir(filePath);
                }, 0);
            },

            resolveLocalFileSystemURI: function (filePath) {

                setTimeout(function () {

                    var checkExist = fs.existsSync(__dirname + "/" + filePath);

                    if (checkExist == true) {
                        success();
                    } else {
                        fail();
                    }
                    function success() {
                        return (__dirname + "/" + filePath);
                    };
                    function fail() {
                        return "File Not Found";
                    }
                }, 0);
            },

            getDirectory: function (filePath) {
                setTimeout(function () {
                    var checkExist = fs.existsSync(__dirname + "/" + filePath);
                    if (checkExist != true) {
                        fs.mkdirSync(__dirname + "/" + filePath);
                    }
                }, 0);
            },

            getFile: function (filePath, options) {
                setTimeout(function () {

                    var fileName = filePath
                    var createFile = options.create;
                    var fileExclusive = options.exclusive;

                    if (createFile != null && createFile != "") {
                        fs.mkdirSync(__dirname + "/" + fileName);
                        return (__dirname + "/" + fileName);
                    } else {
                        return (__dirname + "/" + fileName);
                    }
                })
            }
        };

    };

    var EmailComposer = function () {
        //alert("This is a test");
        return {
            open: function (successFunc,failureFunc,actualOptions) {
                    let toList    = "";
                    let ccList    = "";
                    let bccList   = "";
                    let subject   = "";
                    let body      = "";
                    actualOptions = actualOptions[0];

                    if (actualOptions.to.length > 0)
                    actualOptions.to.forEach(function(tolst){
                        toList  = toList + tolst + ";";
                    });

                    if (actualOptions.cc.length > 0)
                    actualOptions.cc.forEach(function(cclst){
                        ccList  = ccList + cclst + ";";
                    });

                    if (actualOptions.bcc.length > 0)
                    actualOptions.bcc.forEach(function(bcclst){
                        bccList = bccList + bcclst + ";";
                    });

                    subject              = actualOptions.subject;
                    body                 = actualOptions.body;

                    window.location.href = "mailto:" + toList +
                                           "?subject=" + subject +
                                           "&body=" + body + 
                                           "&cc=" + ccList + 
                                           "&bcc=" + bccList;
                },

        }

    }

    var initPlugin = function () {
        objCmdMap.clear();

        //Device
        objCmdMap.add("Device", pluginDevice());

        //InAppBrowser
        objCmdMap.add("InAppBrowser", pluginInAppBrowser());

        //DronaHQ
        objCmdMap.add("DronaHQ", pluginDronaHQ());

        //DHQ Storage
        objCmdMap.add("DHQStorage", pluginDHQStorage());

        //Camera
        objCmdMap.add("Camera", pluginCamera());

        //Local Notification Stub
        objCmdMap.add("LocalNotification", pluginLocalNoti());

        //Test Notification
        objCmdMap.add("Notification",createNotification());

        // Sqllite stub
        objCmdMap.add("SQLitePlugin", pluginSQLite());

        // ConnectionInfo
        objCmdMap.add("NetworkStatus", pluginConnInfo());

        objCmdMap.add("File", getfilePath());

        objCmdMap.add("EmailComposer",EmailComposer());

        //objCmdMap.add("DownloadFiles",downloadFile())
    };
    //TODO : UPDATE THE CODE ACCORDING TO WEBVIEW REQUEST
    var sendMessage = function (objData, isSuccess, callbackId, status, keepCallback) {
        var msgData = {
            callbackId: callbackId,
            success: isSuccess,
            status: status,
            payload: [objData],
            keepCallback: keepCallback
        }

        //TODO : NEED TO CONFIRM AND CHANGE THE SETTINGS
        //var contWindow = $cordovaIFrame[0].contentWindow;
        window.postMessage(JSON.parse(JSON.stringify(msgData)), '*'); //https://github.com/azer/prova/issues/12#issuecomment-40967718
        // ipcRenderer.on('request', function(){
        //     ipcRenderer.sendToHost(JSON.parse(JSON.stringify(msgData)));
        // });
    };

    CordovaWebview.sendMessage = sendMessage;

    var receiveMessage = function (e) {
        var msgData = e.data;
        if (msgData.service && msgData.action) {
            var fnSuccess = function (data) {
                sendMessage(data, true, msgData.callbackId, 1, false);
            };

            var fnError = function (reason) {
                sendMessage(reason, false, msgData.callbackId, 1, false);
            };

            var handler = objCmdMap.get(msgData.service, msgData.action);
            if (handler) {
                handler(fnSuccess, fnError, msgData.args);
            } else {
                console.error("Invalid action selected. Service: " + msgData.service + ", Action: " + msgData.action);
            }
        }
    };

    var sendDocumentEvent = function (eventName, eventData) {
        var contWindow = $cordovaIFrame[0].contentWindow;

        contWindow.cordova.fireDocumentEvent(eventName, eventData);
    };

    var _IsReady = false;
    var _appId = 0;

    return {
        init: function () {
            //Make sure we have a valid iframeId

            //Intialize Command Map
            objCmdMap = new CommandMap();

            //Initialize all the plugins
            initPlugin();

            //console.log("now in init");

            _IsReady = true;
        },

        // changeIFrame: function (iFrameId) {

        //     //Did we get the reference?
        //     if ($('#' + iFrameId).length === 0) {
        //         console.error('Invalid iFrameId passed.');
        //         return;
        //     }

        //     $cordovaIFrame = $('#' + iFrameId);
        // },

        IsReady: function () {
            return _IsReady;
        },

        fireDocumentEvent: function (eventName, eventData) {
            sendDocumentEvent(eventName, eventData);
        },

        setAppId: function (appId) {

            appId = parseInt(appId, 10);

            if (!isNaN(appId)) {
                _appId = appId;
            } else {
                _appId = 0;
            }
        },
        
        receiveMessage : receiveMessage
    }
};
var setJsonData = function (keyName, jsonData) {
    var successData = EJstorage.set(keyName, jsonData);
    if (successData.status) {
        return successData
    }
}
var getAllJsonKeys = function () {
    var successData = EJstorage.keys();
    return successData.data;
}
var getJsonData = function (keyName) {
    var successData = EJstorage.get(keyName);
        return successData.data;
}
var removeJsonData = function (keyName) {
    var successData = EJstorage.remove(keyName);
    return successData;
}
var removeAllJsonData = function () {
    var successData = EJstorage.clear();
    return successData;
}

CordovaWebview = new CordovaWebview();
CordovaWebview.init();
window.CordovaWebview = CordovaWebview;

/*
This is a test to check if adding all the values directly does it work
*/

var _logoutAPI = function(userId) {
}

var _logout = function(userInitiated) {
}

var authToken = function() {
    // var accessToken = localStorage.getItem("accessToken");
    var accessToken = getJsonData('accessToken');
    if (accessToken == null || accessToken == undefined || accessToken.length === 0) {
        _logout();
    }
}

var startPageBlock = function(message) {
    // $.blockUI({
    $.blockUI({
        message: '<p></p>',
        css: {
            border: 'none',
            padding: '20px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: 0.5,
            color: '#fff'
        }
    });
};

var startDivBlock = function($e, message) {
    message = message || 'please wait...';
    $e.block({
        message: '<p>' + message + '</p>',
        css: {
            border: 'none',
            padding: '20px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: 0.5,
            color: '#fff'
        }
    });
};

var updatePageBlockMessage = function(message, doAppend) {
    var msg = '<p>' + message + '</p>';
    if (doAppend) {
        $('.blockUI.blockMsg.blockPage').append(msg);
    } else {
        $('.blockUI.blockMsg.blockPage').html(msg);
    }

}

var stopDivBlock = function($e) {
    $e.unblock();
};

var stopPageBlock = function() {
    $.unblockUI();
};

var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function(e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            } else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        }
        return t
    },
    decode: function(e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t);
        return t
    },
    _utf8_encode: function(e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        }
        return t
    },
    _utf8_decode: function(e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        }
        return t
    }
}

var fnAjaxRequest = function(ajaxURL, ajaxReqMethod, ajaxReqHeader, ajaxReqData, onSucess, onError, contentType) {
    $.ajax({

        type: ajaxReqMethod,
        url: ajaxURL,
        data: ajaxReqData,
        headers: ajaxReqHeader,
        success: onSucess,
        error: onError,
        contentType: contentType || 'application/x-www-form-urlencoded'
    });
};

function onError(jqXHR, textStatus, errorThrown) {
    //Show error message        
    if (jqXHR.status === 500) {
        alert("Oops...Something went wrong!");
    }
}

function fnDronaError(errorCode, reqJson) {
    if (errorCode == 0) {
        swal('Server error!');
    } else if (errorCode == 1) {
        swal('Invalid request');
    } else if (errorCode == 2) {} else if (errorCode == 3) {}
}

//fn: render handlebar-template to html
//inputParam: template_id, data
//return: html

var fnHandlebarTemplate = function(templateId, data) {
    var x = "#" + templateId;
    var source = $("#" + templateId).html();
    var template = Handlebars.compile(source);
    var html = template(data);
    return html;
}



var fnGetAlpha = function(num) {
    if (num > 26) {
        return num;
    } else {
        return String.fromCharCode(64 + num);
    }
};



//function to format dates

var formatDate = function(originalDate) {
    if (window.moment && moment(originalDate).isValid()) {
        var nowDtTime = moment.utc();
        var feedDateTime = moment.utc(originalDate, 'YYYY-MM-DD HH-mm-ss');

        var diffSec = nowDtTime.diff(feedDateTime, 'seconds');
        var retrunVal = '';

        if (diffSec < 1) {
            return "just now";
        }

        if (diffSec < 60) {
            if (diffSec === 1) {
                return diffSec + ' sec ago';
            } else {
                return diffSec + ' secs ago';
            }
        }


        //Difference greater then 60 secs, convert it to minutes
        var diffMin = Math.floor(diffSec / 60);
        if (diffMin < 60) {
            if (diffMin === 1) {
                return diffMin + ' min ago';
            } else {
                return diffMin + ' mins ago';
            }
        }

        //Difference is greater than 60 minutes
        var diffHour = Math.floor(diffMin / 60);
        if (diffHour < 24) {
            if (diffHour === 1)
                return diffHour + ' hour ago';
            else
                return diffHour + ' hours ago';
        }

        //Difference is greater than 24 hours, convert it to days
        var diffDay = Math.floor(diffHour / 24);
        if (diffDay < 8) {
            if (diffDay === 1) {
                return diffDay + ' day ago';
            } else {
                return diffDay + ' days ago';
            }
        }

        //Difference is more than 30 days, send date as it is
        return feedDateTime.local().format('DD MMM');
    } else
        return '';
};

var fireworks = function(elementId, width, height) {

    function Particle(x, y, radius) {
        this.init(x, y, radius);
    }

    Particle.prototype = {

        init: function(x, y, radius) {

            this.alive = true;

            this.radius = radius || 10;
            this.wander = 0.15;
            this.theta = random(TWO_PI);
            this.drag = 0.92;
            this.color = '#fff';

            this.x = x || 0.0;
            this.y = y || 0.0;

            this.vx = 0.0;
            this.vy = 0.0;
        },

        move: function() {

            this.x += this.vx;
            this.y += this.vy;

            this.vx *= this.drag;
            this.vy *= this.drag;

            this.theta += random(-0.5, 0.5) * this.wander;
            this.vx += sin(this.theta) * 0.1;
            this.vy += cos(this.theta) * 0.1;

            this.radius *= 0.96;
            this.alive = this.radius > 0.5;
        },

        draw: function(ctx) {

            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, TWO_PI);
            ctx.fillStyle = this.color;
            ctx.fill();
        }
    };

    // ----------------------------------------
    // Example
    // ----------------------------------------

    var MAX_PARTICLES = 280;
    var COLOURS = ['#69D2E7', '#A7DBD8', '#E0E4CC', '#F38630', '#FA6900', '#FF4E50', '#F9D423'];

    var particles = [];
    var pool = [];

    var demo = Sketch.create({
        container: document.getElementById(elementId),
        fullscreen: false,
        width: width,
        height: height
    });

    demo.setup = function() {

        // Set off some initial particles.
        var i, x, y;

        for (i = 0; i < 20; i++) {
            x = (demo.width * 0.5) + random(-100, 100);
            y = (demo.height * 0.5) + random(-100, 100);
            demo.spawn(x, y);
        }
    };

    demo.spawn = function(x, y) {

        if (particles.length >= MAX_PARTICLES)
            pool.push(particles.shift());

        particle = pool.length ? pool.pop() : new Particle();
        particle.init(x, y, random(5, 40));

        particle.wander = random(0.5, 2.0);
        particle.color = random(COLOURS);
        particle.drag = random(0.9, 0.99);

        theta = random(TWO_PI);
        force = random(2, 8);

        particle.vx = sin(theta) * force;
        particle.vy = cos(theta) * force;

        particles.push(particle);
    }

    demo.update = function() {

        var i, particle;

        for (i = particles.length - 1; i >= 0; i--) {

            particle = particles[i];

            if (particle.alive) particle.move();
            else pool.push(particles.splice(i, 1)[0]);
        }
    };

    demo.draw = function() {

        demo.globalCompositeOperation = 'lighter';

        for (var i = particles.length - 1; i >= 0; i--) {
            particles[i].draw(demo);
        }
    };

    demo.mousemove = function() {

        var particle, theta, force, touch, max, i, j, n;

        for (i = 0, n = demo.touches.length; i < n; i++) {

            touch = demo.touches[i], max = random(1, 4);
            for (j = 0; j < max; j++) demo.spawn(touch.x, touch.y);
        }
    };

}

/* Adding My Code for now as the code does not seem to work with the Diffrent file hope this works */

var postDownlaod = function(file_url, targetPath, pkgChkSum) {
    var chker;
    checksum.file(destLocation + "/" + appVersion + ".zip", function(err, pkgChkSumNew12) {
        pkgChkSumNew = pkgChkSumNew12;
        toDownloadOrNot();
    });

    function toDownloadOrNot() {
        if (pkgChkSumNew == pkgChkSum) {
            chker = 1;
            chkSumCounter++;
            if (chkSumCounter < 3) {
                if (chker == 1) {
                    var preBase = fs.readFileSync(destLocation + "/" + appVersion + ".zip");
                    var decrypted = RNCryptor.Decrypt(preBase, DECRYPTION_KEY);

                    fs.writeFileSync(destLocation + "/" + appVersion + ".zip", decrypted);
                    openfile(targetPath);
                } else {
                    downloadFile(file_url, targetPath, pkgChkSum);
                }
            } else {
                var preBase = fs.readFileSync(destLocation + "/" + appVersion + ".zip");
                var decrypted = RNCryptor.Decrypt(preBase, DECRYPTION_KEY);

                fs.writeFileSync(destLocation + "/" + appVersion + ".zip", decrypted);
                openfile(targetPath);
            }
        }
    }
}

var downloadFile = function(file_url, targetPath, pkgChkSum, appName, iconLink, appSize) {
    //Save variable to know progress
    if (!fs.existsSync(destLocation + "/" + appVersion + "/" + "INDEX.HTML")) {
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
        $('#create-home-screen').removeClass('hide');
        $('#set-app-name').html(appName);
        $('#app-image').css('background-image', "url(" + iconLink + ")");

        var received_bytes = 0;
        var total_bytes = 0;
        out = fs.createWriteStream(targetPath);
        var req = request({
            method: 'GET',
            uri: file_url
        });

        var showProgress = function(received, total) {
            var percentage = (received * 100) / total;
            $('.progress-bar').css('width', percentage + "%");
        }

        //fs.createWriteStream(testing);
        req.pipe(out);

        req.on('response', function(data) {
            //Change the total bytes value to get progress later.
            total_bytes = parseInt(data.headers['content-length']);
        });

        req.on('data', function(chunk) {
            //Update the received bytes
            received_bytes += chunk.length;
            showProgress(received_bytes, total_bytes);
        });

        req.on('end', function() {
            postDownlaod(file_url, targetPath, pkgChkSum);
        });
    } else {
        if (varChkOpnPkg == 1)
            loadFileFinal();
        else {}
        //      openCustomHomeScreenFinalStage();
    }
};

// Eventhandler for file input. 
var openfile = function(fileName) {

    var zip = new AdmZip(fileName);
    var zipEntries = zip.getEntries();
    var dfd = jQuery.Deferred();

    $.when(zip.extractAllTo(destLocation + "/" + appVersion, true)).then(
        //$.when(extract(fileName,{dir:destLocation + "/" + appVersion}, function (err) {})).then(
        function(status) {
            if (varChkOpnPkg == 1)
                loadFileFinal();
            else {}
            // openCustomHomeScreenFinalStage();
        });
    return dfd.promise();
};

var closeApp = function() {
    $('body').on('click', '.closeTopTeamgumGumitBar', function() {
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
        $('#webview1').remove();
        timeSpentInApp(Math.round(+new Date() / 1000));
        clickedActionButton = 0;
        globalPluginVersion = "";
    });
};

var loadFileFinal = function() {
    var closediv = document.createElement('div');
    var appHeight = $('html').css('height');
    var appWidth = $('html').css('width');
    var webview = document.createElement('webview');
    $(webview).attr("disablewebsecurity", "");
    var appRes = appResolution;
    if (appRes.max_width > 0) {
        appWidth = appRes.max_width;
    }
    if (appRes.min_width < appWidth) {
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');
        $(closediv).attr('id', 'webview1');
        $(closediv).css('width', '100%');
        $(closediv).css('height', appHeight);
        $(closediv).append('<div class="pull-right"><div class="pull-right m-l"><a href="#"><img class="closeTopTeamgumGumitBar close" src="images/Cross-Close_black.png"></a></div></div>');

        document.body.appendChild(closediv);
        var b = document.getElementById('webview1');
        $(webview).css('width', '100%')
        $(webview).css('height', appHeight);

        webview.src = destLocation + "/" + appVersion + "/index.html";
        // webview.nodeintegration = false;
        webview.preload = __dirname + "/preload.js" // +" , "+ __dirname+"/myJS/DronaAppPage.js";
        webview.useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"
        //webViewId = webview.id = "thisTest";
        webview.addEventListener('dom-ready', () => {
            webview.openDevTools();
        });
        b.appendChild(webview);

        $('#create-home-screen').addClass('hide');
        timeStampStart = Math.round(+new Date() / 1000);
        closeApp();
    } else {
        alert(appResolution.min_width_msg);
        $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').removeClass('hide');
        $('#create-home-screen').removeClass('hide');
    }
};

var timeSpentInApp = function(timeStampEnd) {
    var onSuccess = function(resp) {};
    var onError = function() {};

    var timeDifference = timeStampEnd - timeStampStart;
    if (timeDifference < 0)
        timeDifference = 0;

    // var userData = JSON.parse(localStorage.getItem('userData'));
    var userData = JSON.parse(getJsonData('userData'));
    var user_id = userData.uid;
    var postData = JSON.stringify({
        "data": {
            "time_spent": timeDifference,
            "ab_id": clickedActionButton,
            "uid": user_id,
            "plugin_version": globalPluginVersion
        },
        "type": "actionButton"
    });
    fnAjaxRequest(API_BASE_URL + 'timespent.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: postData
    }, onSuccess, onError);

};

var timeSpentInMainApp = function(finalTimeStampEnd) {

    var onSuccess = function(resp) {};
    var onError = function() {};


    var timeDifference = timeStampEnd - timeStampMainAppStart;
    if (timeDifference < 0)
        timeDifference = 0;

    // var userData = JSON.parse(localStorage.getItem('userData'));
    var userData = JSON.parse(getJsonData('userData'));
    var user_id = userData.uid;
    var postData = JSON.stringify({
        "type": "app",
        "data": {
            "uid": user_id,
            "time_spent": timeDifference
        }
    });

    fnAjaxRequest(API_BASE_URL + 'timespent.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: postData
    }, onSuccess, onError);
};

var callFromMain = function() {
    if (clickedActionButton != "")
        timeSpentInApp(Math.round(+new Date() / 1000));
};

var callToSendTimeSpent = function() {
    timeSpentInMainApp(Math.round(+new Date() / 1000));
};

var callOnReopen = function() {
    if (clickedActionButton != "")
        timeStampStart = Math.round(+new Date() / 1000);
};

var callOnReopenMainApp = function() {
    timeStampMainAppStart = Math.round(+new Date() / 1000);
    window.objDronaHQ.fetchKnowledgeBase();
    getAppMeta();
    callCheckForUpdate();
};

var afterSessionTimeOut = function() {
    var onSuccess = function(data) {
        data = JSON.parse(data);
        respResponse = parseInt(data.resp, 10)
        if (respResponse === 0) {
            swal({
                    title: "Oops",
                    text: "Something Went Wrong, Please Try Loging in again",
                    closeOnConfirm: true
                },
                function() {
                    _logout();
                });
        } else {
            localStorage.setItem("accessToken", data.access_token.toString());
            localStorage.setItem("refreshToken", data.refresh_token.toString());
            setJsonData("accessToken", data.access_token);
            setJsonData("refreshToken", data.refresh_token);
        }
    }
    // if (localStorage.getItem('refreshToken')) {
    //     refreshToken = localStorage.getItem('refreshToken');
    //     var ajaxReqData = {
    //         device_id: DEVICE_ID,
    //         refresh_token: refreshToken
    //     };
    // }
    var refreshToken = getJsonData("refreshToken");
    // var refreshToken = localStorage.getItem("refreshToken");
    if (refreshToken != null && refreshToken != undefined && refreshToken != "") {
        var os = require("os");
        var networkType = os.networkInterfaces();
        var getMacId = "";

        if (!(networkType.Ethernet == undefined)) {
            getMacId = networkType.Ethernet[0].mac;
        } else {
            getMacId = networkType.WiFi[0].mac
        }

        var ajaxReqData = {
            device_id: getMacId,
            refresh_token: refreshToken
        };

        fnAjaxRequest(API_BASE_URL + 'refreshtoken.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: ajaxReqData
        }, onSuccess, onError);
    } else {
        _logout()
    }

};

var getAppMeta = function() {
    var os = require('os');
    var deferred = Q.defer();
    var userData = getJsonData("userData");
    var networkType = os.networkInterfaces();
    var getMacId = "";
    var userId = userData.uid

    userData = JSON.parse(userData);

    if (os.type().toLowerCase() != "darwin")
        if (networkType.Ethernet == undefined)
            getMacId = networkType.WiFi[0].mac
        else
            getMacId = networkType.Ethernet[0].mac;
    else
        if (networkType.en1 == undefined)
            getMacId = networkType.lo0[0].mac;
        else
            getMacId = networkType.en1[0].mac;

    var ajaxReqData = {
        "uid": userId,
        "device_id": getMacId
    }

    var onSuccess = function(data) {
        data = JSON.parse(data)
        if (!(data.resp)) {
            localStorage.setItem('appMeta', JSON.stringify(data));
            setJsonData('appMeta', JSON.stringify(data));
        } else if (data.resp == 3) {
            var errorMessage;
            if (data.lock_msg == undefined || data.lock_msg == "")
                errorMessage = "Your account has been locked. Please upgrade your license or contact admin or mail us at <a href=" + mailToID + ">" + SUPPORT_EMAIL_ID + "</a>";
            else
                errorMessage = data.lock_msg;
            swal({
                title: "",
                text: errorMessage,
                type: "success",
                confirmButtonColor: "#28bc6a",
                confirmButtonText: "Okay!",
                closeOnConfirm: true
            }, function() {
                _logout();
            });
        }
        deferred.resolve();
    }

    var oldGetAppMeta = getJsonData('appMeta');

    if (oldGetAppMeta != undefined) {
        fnAjaxRequest(API_BASE_URL + 'getappmeta.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: ajaxReqData
        }, onSuccess, onError);
        deferred.resolve();
    } else {
        fnAjaxRequest(API_BASE_URL + 'getappmeta.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: ajaxReqData
        }, onSuccess, onError);
    }

    return deferred.promise;
};

var callCheckForUpdate = function() {
    var os = require('os');
    var freeMemory = os.freemem();
    var deferred = Q.defer();
    var userData = getJsonData("userData");
    var osVersion = os.release();
    var deviceName = os.hostname();
    var memoryValue = process.memoryUsage();
    var memoryTotal = memoryValue.rss + memoryValue.heapTotal + memoryValue.heapUsed + memoryValue.external;
    var networkType = os.networkInterfaces();
    var getMacId = "";
    userData = JSON.parse(userData);

    if (os.type().toLowerCase() != "darwin")
        if (networkType.Ethernet == undefined)
            getMacId = networkType.WiFi[0].mac
        else
            getMacId = networkType.Ethernet[0].mac;
    else
        if (networkType.en1 == undefined)
            getMacId = networkType.lo0[0].mac;
        else
            getMacId = networkType.en1[0].mac;

    var onSuccess = function(data) {
        data = JSON.parse(data);

        switch (data.resp) {
            case "0":
                swal('',
                    'Server mein gadbad',
                    'error');
                break;
            case "1":
                swal('',
                    'Request mein gadbad',
                    'error');
                break;
            case "3":
                swal({
                    title: "",
                    text: "Invalid User Kindly Login Again",
                    type: "Error",
                    confirmButtonColor: "#28bc6a",
                    confirmButtonText: "Okay!",
                    closeOnConfirm: true
                }, function() {
                    _logout();
                });
                break;
            case "4":
                console.log("Nice all is updated");
                break;
        }

        deferred.resolve();
    }

    var ajaxReqData = {
        "uid": userData.uid,
        "device_type": DEVICE_TYPE,
        "device_id": getMacId,
        "device_name": deviceName,
        "app_name": APP_NAME,
        "app_version": APP_NAME,
        "os_version": osVersion,
        "model": "DEV_MODEL",
        "free_memory": freeMemory,
        "used_by_app": memoryTotal,
        "is_rooted": 0
    };

    fnAjaxRequest(API_BASE_URL + 'checkforupdate.aspx', 'POST', {
        Authorization: 'Bearer ' + base64String
    }, {
        abc: ajaxReqData
    }, onSuccess, onError);

    return deferred.promise;
};

/* JSON STORAGE DECLARATION FOR ELECTRON JSON STORAGE
   MOST OF THEM ARE SELF EXPLANATORY SO USE THEM :) */

var setJsonData = function(keyName, jsonData) {
    var successData = EJstorage.set(keyName, jsonData);
    if (successData.status)
        return successData
};

var getAllJsonKeys = function() {
    var successData = EJstorage.keys();
    return successData.data;
};

var getJsonData = function(keyName) {
    var successData = EJstorage.get(keyName);
    return successData.data;
};

var removeJsonData = function(keyName) {
    var successData = EJstorage.remove(keyName);
    return successData;
};

var removeAllJsonData = function() {
    var successData = EJstorage.clear();
    return successData;
};

var toSetHomeScreenOrNot = function(aBData) {

    var yeHaiABArray = aBData;

    for (var i = 0; i < yeHaiABArray.length; i++) {

        if (yeHaiABArray[i].plugin_version.open_code != null && yeHaiABArray[i].plugin_version.open_code != "") {
            NewHomeScreenOpened = 1;
            var appId = yeHaiABArray[i].ab_id;
            var pkgLink = yeHaiABArray[i].action_url;
            var pkgChkSum = yeHaiABArray[i].plugin_version.package_checksum;
            var iconLink = yeHaiABArray[i].image_url;
            var appName = yeHaiABArray[i].title;
            var appSize = yeHaiABArray[i].plugin_version.package_size;
            appVersion = yeHaiABArray[i].plugin_version.version_code;

            if (!fs.existsSync(__dirname + "/piz")) {
                fs.mkdirSync(__dirname + "/piz");
            }

            destLocation = __dirname + "/piz/" + appId;
            var fileLocation = __dirname + "/piz/" + appId + "/" + appVersion + ".zip";

            if (!fs.existsSync(destLocation)) {
                fs.mkdirSync(destLocation);
            }

            if (!fs.existsSync(destLocation + "/" + appVersion)) {
                fs.mkdirSync(destLocation + "/" + appVersion);
            }
            varChkOpnPkg = 0;

            downloadFile(pkgLink, destLocation + "/" + appVersion + ".zip", pkgChkSum, appName, iconLink, appSize);
        }
    }
};

var openCustomHomeScreenFinalStage = function() {
    //NewHomeScreenOpened = 1;
    $('#dvWebView , #confirmCloseModal , .aw-modal-overlay').addClass('hide');

    var appHeight = $('html').css('height');
    var appWidth = $('html').css('width');
    var webview = document.createElement('webview');

    $(webview).attr("disablewebsecurity", "");
    $(webview).css('width', '100%')
    $(webview).css('height', appHeight);

    webview.src = destLocation + "/" + appVersion + "/ index.html";
    webview.preload = "./preload.js";
    webview.useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"

    webview.addEventListener('dom-ready', () => {
        webview.openDevTools();
    });

    document.body.appendChild(webview);

};

/* END OF JSON STORAGE DECLARATION */

/* Added code just to make sure that we dont get logged out if we are getting into the application after a long time :D */
/* Finally end of my code */

//call on landing page after login
var DronaAppLanding = function() {
    

    var objUser = {};
    var storeUser, storePlugin, storeNoti;
    var user, u_uid;

    if (getJsonData('accessToken') != null) {
        user = getJsonData('userData');
        u_uid = JSON.parse(user);

        var user_id = u_uid.uid;
        var accessToken = getJsonData('accessToken');

        base64String = Base64.encode(accessToken);
    }


    var _initUser = function() {
        // var userData = localStorage.getItem('userData');
        // var accessToken = localStorage.getItem('accessToken');

        var userData = getJsonData('userData');
        var accessToken = getJsonData('accessToken');
        if (!userData) {
            return;
        }
        objUser = JSON.parse(userData);

        //Populate the store
        storeUser.save({
            key: 'uinfo',
            data: objUser
        });

        storeUser.save({
            key: 'u-token',
            data: accessToken
        })
    };

    //fn: load app list
    //inputParam: {uid:user_id}
    var _loadAppList = function() {


    }

    var _loadInboxData = function(_maxInboxId, _maxInboxResult, searchText, filterType) {
        //var deferred = Q.defer();
        var allJsonKeys = getAllJsonKeys();
        var getInbox = "inboxData";
        // $('#appListLoader').removeClass('hide');

        // function onSuccess(respdata) {
        //     setJsonData('inboxData', respdata);
        //     var data = JSON.parse(respdata);

        //     if (data.moduleInbox) {

        //         var arrAppNoti = _.filter(data.moduleInbox, {
        //             content_json: {
        //                 sub_type: 'app_noti'
        //             }
        //         });

        //         _.forEach(arrAppNoti, function(objModule) {
        //             var objNotiData = objModule.content_json.noti_data;
        //             var appData = objNotiData.app_data;

        //             if (appData) {
        //                 storeNoti.save({
        //                     key: 'noti-' + objNotiData.noti_id,
        //                     data: JSON.parse(appData)
        //                 });
        //             }
        //         });

        //         // Reset unread inbox badge count
        //         storeUser.save({
        //             key: 'unread-inbox',
        //             data: 0
        //         });

        //         deferred.resolve(data);

        //     } else if (data.resp) {
        //         var errorCode = data.resp;
        //         if (errorCode == 0) {
        //             deferred.reject(data);
        //         } else if (errorCode == 1) {
        //             deferred.reject(data);
        //         } else if (errorCode == 2) {
        //             deferred.reject(data);
        //         } else if (errorCode == 3) {
        //             // swal({
        //             //         title: "Oops",
        //             //         text: "Session Expired",
        //             //         closeOnConfirm: true
        //             //     },
        //             //     function () {
        //             //         _logout();
        //             //     });
        //             afterSessionTimeOut();
        //         }
        //     }
        // }

        // var postData = JSON.stringify({
        //     uid: user_id,
        //     inbox_id: _maxInboxId,
        //     inbox_count: _maxInboxResult,
        //     search_text: searchText,
        //     filter_type: filterType
        // });
        // var valPresent = jQuery.inArray(getInbox, allJsonKeys)
        // if (valPresent > -1) {
        //     var getInbox = getJsonData(getInbox);
        //     onSuccess(getInbox);
        //     fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {

        //         Authorization: 'Bearer ' + base64String
        //     }, {
        //         abc: postData
        //     }, onSuccess, onError);
        // } else {
        //     fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
        //         Authorization: 'Bearer ' + base64String
        //     }, {
        //         abc: postData
        //     }, onSuccess, onError);
        // }
        //return deferred.promise;
    }

    var loadMore = true;
    var pageSize = 10;
    var startIndex = 0;
    //fn: load category detail
    //pagination support
    //inputParam: catId, click
    //catId: category id
    //click: bool [set true while click on category icon; false on load more]
    var _loadCatDetail = function(catId, click) {

        //var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');
        $('#content_loader').removeClass('hide');

        //$('#uListCategoryDetail').append($vatLoaderTemp);

        function onSuccess(respData) {

            var data = JSON.parse(respData);
            if (data.module_content) {
                var tempData = {
                    module_content: data.module_content
                }
                var html = fnHandlebarTemplate('template-cat-detail-v2', data);
                //$('#frameWebview').remove();

                if (startIndex == 0) {
                    $('#dvContentListContainer').empty();
                }

                startIndex = startIndex + data.module_content.length;

                if ((startIndex == data.total_result_count) || (data.module_content.length < pageSize)) {
                    loadMore = false;
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                //$('#uListCategoryDetail').append(HTML);
                $('#dvContentListContainer').append(html);

                $('#loaderIframeWebView').addClass('hide');
            } else if (data.resp) {
                $('#loaderIframeWebView').addClass('hide');

                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    //$('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    afterSessionTimeOut();
                }
            }
        }

        var postData = JSON.stringify({
            type: "shortContentJson",
            data: {
                cat_id: catId,
                uid: user_id,
                start_index: startIndex,
                expected_size: pageSize,
                filter_type: '',
                search_text: ''
            }
        });

        fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var _loadCatContent = function(cId, cType) {
        var elapsed;
        var start = new Date();
        $('#content_loader').removeClass('hide');

        function onSuccess(respData) {

            var data = JSON.parse(respData);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    swal('Sorry', ' Content no longer available!');
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            } else {
                var tempData;
                switch (cType) {
                    case 'ig':
                        tempData = {
                            image_array: data.image_url,
                            type: cType,
                            title: data.title
                        };
                        break;
                    case 'v':
                        tempData = {
                            type: cType,
                            thumbnail_url: data.thumbnail_url.high_thumb,
                            title: data.title,
                            cid: data.cid,
                            comment_count: data.comment_count,
                            length: data.length,
                            modify_date: data.modify_date,
                            author: data.author,
                            description: data.description
                        };
                        break;
                    case 'audio':
                        tempData = {
                            title: data.title,
                            length: data.length,
                            type: cType,
                            comment_count: data.comment_count,
                            audio_url: data.audio_url
                        }
                        break;
                    case 'article':
                        tempData = data;
                        break;
                    case 'pdf':
                        tempData = data;
                        var pdf_url = '/pdfrenderer.ashx?url=' + data.pdf_url.pdf_url + '&cid=' + cId;
                        pdf_url = encodeURIComponent(pdf_url);
                        tempData = {
                            yoData: pdf_url,
                            type: cType,
                            cid: cId,
                            pdf_size: data.pdf_url.pdf_size,
                            title: data.title,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            description: data.description,
                            has_third_screen: true
                        };
                        break;
                    case 'p':
                        tempData = {
                            description: data.description,
                            yoData: data.slide_data,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            has_third_screen: true,
                            length: data.slide_data.length
                        };
                        break;
                    case 'q':
                        tempData = {
                            description: data.description,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            yoData: data.quiz_data.question,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            length: data.quiz_data.question.length,
                            has_third_screen: true
                        }
                        break;
                    case 'e':
                        break;
                    case 'text':
                        tempData = data;
                        break;
                    case 's':
                        tempData = {
                            description: data.description,
                            type: cType,
                            cid: data.cid,
                            title: data.title,
                            yoData: data.survey_data.question,
                            author: data.author,
                            comment_count: data.comment_count,
                            modify_date: data.modify_date,
                            length: data.survey_data.question.length,
                            has_third_screen: true
                        }
                        break;
                    case 'form':
                        tempData = {
                            form_url: data.form_url + '&dm_uid=' + user_id
                        }
                        break;
                    case 'embed':
                        tempData = {
                            title: data.title,
                            type: cType,
                            embed_data: data.embed_data
                        };
                        break;
                    case 'n':
                        tempData = data;
                        break;

                }
            }

            if (cType === 'form') {
                //There is not meta with this content
                //directly open the form_url in webview

                $('#dvContentContainer').addClass('hide');
                $('#dvIframeContainer').removeClass('hide');

                $('#frameWebview').attr('src', tempData.form_url);

                console.log(tempData.form_url);
                $modal.find('.aw-modal-header').removeClass('webview');
                return;
            }

            //Handle app notification
            if (cType === 'text') {
                if (tempData.sub_type === 'app_noti') {
                    //This is a app notification
                    var appId = tempData.noti_data.app_id;
                    var notiId = tempData.noti_data.noti_id;

                    storePlugin.get('app-' + appId, function(data) {
                        var objApp = data.data;
                        var appAction = objApp.action.toLowerCase();
                        var appUrl = '';
                        if (appAction === 'webview') {
                            appUrl = objApp.action_url;
                        } else if (appAction === 'localview' || appAction == 'internalview') {
                            if (objApp.sub_type === 'plugin') {
                                appUrl = objApp.plugin_version.web_url;
                            }
                        }

                        if (appUrl) {
                            $('#dvContentContainer').addClass('hide');
                            $('#dvIframeContainer').removeClass('hide');

                            appUrl = _fnAppendUserId(appUrl, notiId);
                            _webViewPopup(appUrl, true, false, appId);

                            //If close button to be hidden, hide the header
                            if (objApp.sub_type === 'plugin') {
                                if (objApp.plugin_version.hide_close_button) {
                                    //Hide the headr
                                    $('#dvModalHeader').addClass('hide');

                                    //Remove padding from
                                    $('#dvModalHeader').next().css('padding-bottom', '0');

                                }
                            }

                            return;
                        } else {
                            swal("This app is not available on the web!");
                        }
                    });

                    return;
                }
            }

            $modal.find('.aw-modal-header').removeClass('webview');

            $('#dvContentContainer').removeClass('hide');

            $('#dvIframeContainer').addClass('hide');
            $('#loaderIframeWebView').addClass('hide');

            var HTML = fnHandlebarTemplate('tmpl-cms-content', tempData);

            $('#dvContentMeta').html('');
            $('#dvContentMeta').html(HTML);
            //$('#dvContentMeta').removeClass('hidden');
            //$('#dvContentMeta').addClass('fdivisible');
            if (cType == 'pdf') {
                //$("#iframePdfViewer").attr('src', 'web/viewer.html?file=' + pdf_url);
            } else if (cType == 'audio') {

                var playerInstance = jwplayer("audiodiv");
                playerInstance.setup({

                    file: data.audio_url.audio_url,

                    // URL to the image that should be shown before the video is started
                    image: "",
                    title: data.title,
                    width: '100%',
                    height: '50px',
                });
            } else if (cType == 'v') {
                var fnVideoStreamSuccess = function(respData) {
                    var streamData = JSON.parse(respData);

                    if (streamData.resp) {
                        var errorCode = streamData.resp;
                        if (errorCode == 0) {
                            swal('Oops!', 'Server error!', 'error');
                        } else if (errorCode == 1) {
                            swal('Oops!', 'Invalid request', 'error');
                        } else if (errorCode == 2) {
                            swal('Sorry', ' Content no longer available!');
                        } else if (errorCode == 3) {
                            // swal({
                            //     title: "Oops",
                            //     text: "Session Expired",
                            //     closeOnConfirm: true
                            // });
                            afterSessionTimeOut();
                        }
                    } else {
                        var rtmpUrl = streamData.rtsp_stream_url.replace('rtsp://', 'rtmp://');
                        var playerInstance = jwplayer("videodiv");
                        playerInstance.setup({
                            file: rtmpUrl,
                            // URL to the image that should be shown before the video is started
                            image: data.thumbnail_url.high_thumb,
                            title: data.title,
                            width: '100%',
                            aspectratio: '16:9'
                        });
                    }
                }
                var postData1 = JSON.stringify({
                    type: "GetStream",
                    data: {
                        uid: user_id,
                        cid: cId
                    }
                });
                fnAjaxRequest(API_BASE_URL + 'getstreamurl.aspx', 'POST', {
                    Authorization: 'Bearer ' + base64String
                }, {
                    abc: postData1
                }, fnVideoStreamSuccess, onError);
            }

            elapsed = new Date() - start;
        }

        if (cType == 'v') {
            var postData = JSON.stringify({
                type: "longContentJson",
                data: {
                    cid: cId,
                    uid: user_id
                }
            });
            fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            var postData = JSON.stringify({
                type: "longContentJson",
                data: {
                    cid: cId,
                    uid: user_id
                }
            });
            fnAjaxRequest(API_BASE_URL + 'getcategorycontent.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }

        return elapsed;
    }

    //inbox/notification

    var _maxInboxId = 0;
    var _maxInboxResult = 15;
    var _loadInbox = function() {
        var allJsonKeys = getAllJsonKeys();
        var catContent = "catContent";
        $('#inbox').addClass('active');
        $('#bookmark').removeClass('active');
        var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');

        $('#spPaneName').text('Inbox');

        $('#uListCategoryDetail').append($vatLoaderTemp);

        function onSuccess(respdata) {
            setJsonData('catContent', respdata);
            var data = JSON.parse(respdata);

            if (data.moduleInbox) {
                if (_maxInboxId === 0) {
                    $('#dvCategContentList').html('');
                }
                var HTML = fnHandlebarTemplate('template-inbox-list-v2', data);
                //$('#uListCategoryDetail .js-cat-load-more-container').remove();
                $('#dvCategContentList').append(HTML);
                $('#uListCategoryDetail  #categoryLoader').remove();

                var moduleCount = data.moduleInbox.length;
                if (moduleCount == 0) {
                    $('#dvCategContentList').append('<div class="card__content card__padding text-center"><article class="card__article"><h3>No Notifications Available</h3></article></div>');
                    $("#btnLoadMoreCategoryDetail").addClass("hide");
                    return;
                }
                $("#btnLoadMoreCategoryDetail").removeClass("hide");

                _maxInboxId = data.moduleInbox[moduleCount - 1].Inbox_id;

                //Show load more
                if ((moduleCount < _maxInboxResult)) {
                    loadMore = false;
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                //Highligh the inbox wala tab
                $('.js-menu-item').removeClass('active');

                //Store the app notification data
                var arrAppNoti = _.filter(data.moduleInbox, {
                    content_json: {
                        sub_type: 'app_noti'
                    }
                });

                _.forEach(arrAppNoti, function(objModule) {
                    var objNotiData = objModule.content_json.noti_data;
                    var appData = objNotiData.app_data;

                    if (appData) {
                        storeNoti.save({
                            key: 'noti-' + objNotiData.noti_id,
                            data: JSON.parse(appData)
                        });
                    }
                });

                // Reset unread inbox badge count
                storeUser.save({
                    key: 'unread-inbox',
                    data: 0
                });

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    $('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            }
        }

        var postData = JSON.stringify({
            uid: user_id,
            inbox_id: _maxInboxId,
            inbox_count: _maxInboxResult
        });
        var valPresent = jQuery.inArray(catContent, allJsonKeys)
        if (valPresent > -1) {
            var catContentData = getJsonData("catContent");
            onSuccess(catContentData);
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        } else {
            fnAjaxRequest(API_BASE_URL + 'contentinbox.aspx', 'POST', {
                Authorization: 'Bearer ' + base64String
            }, {
                abc: postData
            }, onSuccess, onError);
        }
    }

    var _maxBookmarkId = 0;
    var _maxBookmarkResult = 20;
    var _loadBookmark = function() {
        $('#bookmark').addClass('active');
        $('#inbox').removeClass('active');
        $('#spPaneName').text('Bookmark');
        var $vatLoaderTemp = $('#categoryLoader').clone().removeClass('hide');
        if (_maxBookmarkId === 0) {
            $('#dvCategContentList').html('');
        }
        $('#uListCategoryDetail').append($vatLoaderTemp);

        //Highligh the inbox wala tab
        $('.js-menu-item').removeClass('active');
        $('.js-appitem').removeClass('active');

        var postData = {
            type: 'getMyBookmark',
            data: {
                uid: user_id,
                bookmark_id: _maxBookmarkId,
                bookmark_count: _maxBookmarkResult
            }
        };

        var fnSuccess = function(respData) {
            var data = JSON.parse(respData);

            if (data.user_bookmark) {
                var moduleCount = data.user_bookmark.length;
                if ((moduleCount < _maxBookmarkResult)) {
                    loadMore = false;
                    $('#tempLoadMoreCategDetail').addClass('hide');
                }

                if (loadMore) {
                    $('#tempLoadMoreCategDetail').removeClass('hide');
                }

                var HTML = fnHandlebarTemplate('tmpl-bookmark-v2', data);
                //$('#uListCategoryDetail .js-cat-load-more-container').remove();
                $('#dvCategContentList').append(HTML);
                $('#uListCategoryDetail #categoryLoader').remove();

                if (moduleCount > 0) {
                    _maxBookmarkId = data.user_bookmark[moduleCount - 1].bookmark_id;
                }

                //Show load more


            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    var $tempNoCategoryDetailMsg = $('#tempNoCategoryDetailMsg').clone().removeClass('hide');
                    $('#dvCategContentList').html('');
                    $('#uListCategoryDetail').html($tempNoCategoryDetailMsg);
                } else if (errorCode == 3) {
                    // swal({
                    //         title: "Oops",
                    //         text: "Session Expired",
                    //         closeOnConfirm: true
                    //     },
                    //     function () {
                    //         _logout();
                    //     });
                    afterSessionTimeOut();
                }
            }
        };

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, fnSuccess, onError);
    }

    //comments list function
    //Show in that box
    var _loadCommentlist = function(cId) {
        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            //Hide the loader
            $('#dvCommentList').find('.list-loading').addClass('hide');

            //Reset the comment textbox height
            $('#txtAddComment').val('').trigger('input');

            if (data.comment_list) {
                var HTML = fnHandlebarTemplate('template-comment-list', data);
                var length = data.comment_list.length;

                $('#dvCommentList').find('.list-content > ul').html(HTML);
            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {} else if (errorCode == 1) {

                } else if (errorCode == 2) {

                } else if (errorCode == 3) {

                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "getComments",
            data: {
                uid: user_id,
                cid: cId
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _objUserList = {
        start_index: 0
    };

    var _loadUserList = function() {

        function onSuccess(respData) {
            var objData = JSON.parse(respData);

            //Update pointer
            if (objData.user_list) {

                if (objData.user_list.length === 0) {
                    $('#btnLoadMoreRecommList').addClass('hide');
                } else {
                    $('#btnLoadMoreRecommList').removeClass('hide');
                }

                _objUserList.start_index = _objUserList.start_index + 25;

                //Hide the loader
                $('#dvRecommList').find('.list-loading').addClass('hide');
                $('#btnLoadMoreRecommList').prop('disabled', false);

                //Get HTML from template 
                var HTML = fnHandlebarTemplate('tmpl-recomm-list', objData);
                $('#dvRecommList').find('.list-content > ul').append(HTML);
            } else if (objData.resp == '2') {
                $('#btnLoadMoreRecommList').addClass('hide');
                $('#dvRecommList').find('.list-loading').addClass('hide');
            }


        }

        var postData = {
            type: 'getUserList',
            data: {
                uid: user_id,
                start_index: _objUserList.start_index,
                expected_size: 25,
                start_with_alphabet: '',
                search_text: $.trim($('#txtSearchRecommList').val())
            }
        }

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);

    }

    var _fnSetRating = function(appRating) {
        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
        }
        //AppCatalogue.aspx

        var postData = JSON.stringify({
            type: "ratePluginApp",
            data: {
                uid: user_id,
                icon_id: 678,
                icon_type: "a",
                app_version: "1.2.3",
                rating: 4
            }
        });

        fnAjaxRequest(API_BASE_URL + 'AppCatalogue.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //Send contnet recommendation
    var _sendRecomm = function(contId, toUserId, $thisBtn) {
        //Show loading on this button
        var ladda = $thisBtn.ladda();
        // Start loading
        ladda.ladda('start');

        function onSuccess(data) {
            ladda.ladda('stop');

            var objData = JSON.parse(data);

            if (objData.success) {
                $thisBtn.next().removeClass('hide');
                $thisBtn.remove();
            }
        };

        var postData = {
            type: 'setRecommend',
            data: {
                uid: user_id,
                cid: contId,
                recomm_to_uid: [toUserId]
            }
        };

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);
    }

    //delete inbox entry
    var _delInboxEntry = function(inbxid, callback) {

        var deferred = Q.defer();

        function onSuccess(respdata) {
            //callback();
            var data = JSON.parse(respdata);

            if (data.success) {
                //_maxInboxId = 0;
                //_loadInbox();

                deferred.resolve(data);
            }

            //else if (data.resp) {
            //    var errorCode = data.resp;
            //    if (errorCode == 0) {
            //        swal('Oops!', 'Server error!', 'error');
            //    }
            //    else if (errorCode == 1) {
            //        swal('Oops!', 'Invalid request', 'error');
            //    }
            //    else if (errorCode == 3) {
            //        swal("Invalid User.");
            //    }
            //}

        }

        var postData = JSON.stringify({
            type: "deleteInboxContent",
            data: {
                uid: user_id,
                inbox_id: inbxid
            }
        });

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //add comments function
    var _addcomment = function(cId, user_comment) {

        var deferred = Q.defer();

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            //Enable the button
            $('#btnPostComment').prop('disabled', false);
            $('#txtAddComment').val('');
            if (data.success) {

                var objComment = {
                    comment_list: [{
                        comment_date: '',
                        user_comment: user_comment,
                        user_name: objUser.user_name,
                        user_profile_url: objUser.user_profile_image
                    }]
                };

                var HTML = fnHandlebarTemplate('template-comment-list', objComment);
                var $ulComment = $('#dvCommentList').find('.list-content > ul');
                $ulComment.append(HTML);
                $ulComment.animate({
                    scrollTop: $ulComment.prop("scrollHeight")
                }, 500);

            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {

                } else if (errorCode == 3) {


                } else if (errorCode == 4) {

                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "addComment",
            data: {
                uid: user_id,
                cid: cId,
                user_comment: user_comment
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //add like function
    var _addlike = function(cid, likeStatus) {

        var deferred = Q.defer();

        if (likeStatus == "0") {
            //Remove filled
            $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');
        } else {
            //Set filld
            $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhitefilled.png');
        }

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.success) {
                $('#btnLikeCont').data('likeStatus', likeStatus);
            } else if (data.resp) {
                //Reset image switch
                if (likeStatus == "0") {
                    //Remove filled
                    $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhitefilled.png');
                } else {
                    //Set filld
                    $('#btnLikeCont').find('img').attr('src', 'images/TGTB_heartwhiteunfilled.png');
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "setLike",
            data: {
                uid: user_id,
                cid: cid,
                like_status: likeStatus
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);

        return deferred.promise;
    }

    //add bookmark function
    var _addbkmrk = function(cid, bkmrkStatus) {

        var deferred = Q.defer();

        //Show that wala image
        if (bkmrkStatus == "0") {
            //Remove filled
            $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
        } else {
            //Set filld
            $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhitefilled.png');
        }

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.success) {
                $('#btnBookmarkCont').data('bookmarkStatus', bkmrkStatus);
            } else if (data.resp) {
                //Reset image switch
                if (bkmrkStatus == "0") {
                    //Remove filled
                    $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhitefilled.png');
                } else {
                    //Set filld
                    $('#btnBookmarkCont').find('img').attr('src', 'images/TGTB_starwhiteunfilled.png');
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "setBookmark",
            data: {
                uid: user_id,
                cid: cid,
                bookmark_status: bkmrkStatus
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _getbkmrks = function() {
        var deferred = Q.defer();
        /* ALSO UPDATE THE ONSUCCESS */
        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        var postData = JSON.stringify({
            type: "getMyBookmark",
            data: {
                uid: user_id,
                bookmark_id: 1,
                bookmark_count: 10
            }
        });

        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    //get worth-its/like function
    var _loadlikelist = function(cId) {

        var deferred = Q.defer();

        $('#comment_box').removeClass('hidden');

        function onSuccess(respdata) {
            var data = JSON.parse(respdata);

            if (data.likes_list) {
                $('#likesList').html('');

                var HTML = fnHandlebarTemplate('template-like-list', data);
                var length = data.likes_list.length;

                $("#likecount").html(length);
                $('#likesList').append(HTML);
            } else if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else if (errorCode == 2) {
                    $('#likesList').html('Oops! No Likes!Be the first to like');

                } else if (errorCode == 3) {
                    // swal({
                    //     title: "Oops",
                    //     text: "Session Expired",
                    //     closeOnConfirm: true
                    // });
                    afterSessionTimeOut();
                }
            }
            deferred.resolve(data);
        }

        var postData = JSON.stringify({
            type: "getLikes",
            data: {
                uid: user_id,
                cid: cId
            }
        });

        fnAjaxRequest(API_BASE_URL + 'community.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);

        return deferred.promise;
    }

    //analytics functions
    var article_accessed = function(contId, timeSpent) {
        //var conId = "4090";
        //var timeSpent = "5";
        var in_browser = "1";
        var from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "articleWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                in_browser: in_browser,
                from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var embed_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var in_browser = "1";
        var from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "embedWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                in_browser: in_browser,
                from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var video_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var watch_from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "videoWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent,
                watch_from: from
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var pdf_accessed = function(contId, timeSpent) {
        var conId = "4090";
        var timeSpent = "5";
        var watch_from = "App";

        function onSuccess(result) {
            var data = JSON.parse(result);
            if (data.resp) {
                var errorCode = data.resp;
                if (errorCode == 0) {
                    swal('Oops!', 'Server error!', 'error');
                } else if (errorCode == 1) {
                    swal('Oops!', 'Invalid request', 'error');
                } else {
                    swal("analytic submitted");
                }
            }
        }
        var postData = JSON.stringify({
            type: "pdfWatched",
            data: {
                uid: user_id,
                cid: contId,
                time_spent: timeSpent
            }
        });
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
    }

    var _webViewPopup = function(webUrl, alreadyOpen, yoCustomHome, appId) {

        var iframeId = 'frameWebview';
        $('#dvWebviewMsg').removeClass('hide');
        if (yoCustomHome) {
            iframeId = 'frmCustomHome';
            $('#dvWebviewMsg').addClass('hide');
        }

        // Check if Cordova webview is initialized
        if (typeof objCordovaWebView != 'undefined') {
            //Set the current iframe
            objCordovaWebView.changeIFrame(iframeId);
        } else {
            //Initialize the cordova webview
            objCordovaWebView = new CordovaWebview();
            objCordovaWebView.init(iframeId);
        }

        if (appId > 0) {
            objCordovaWebView.setAppId(appId);
        }

        if (!alreadyOpen) {
            $modal = $('#dvWebView');
            $overlay = $modal.next();
            $overlay.addClass('state-show');
            $modal.removeClass('state-leave').addClass('state-appear');
        }

        $('#loaderIframeWebView').removeClass('hide');

        //Hide the headr
        $modal.find('.aw-modal-header').addClass('webview');

        //Hide the content div
        $('#dvContentContainer').addClass('hide');


        if (yoCustomHome) {
            $('#frmCustomHome').removeClass('hide').attr('src', webUrl);
            $('#frameWebview').addClass('hide');
        } else {
            $('#frameWebview').removeClass('hide').attr('src', webUrl);
            $('#frmCustomHome').addClass('hide');
        }
    }

    /* WORK IN PROGRESS */
    var _handleTheMedia = function(mediaUrl, mediaType) {
        var deferred = Q.defer();
        /* ALSO UPDATE THE ONSUCCESS */
        function onSuccess(respdata) {
            var data = JSON.parse(respdata);
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        var postData = JSON.stringify({
            type: "getMyBookmark",
            data: {
                uid: user_id,
                bookmark_id: 1,
                bookmark_count: 10
            }
        });
        /* LATER DO UPDATE THE URL TO HIT hehehe */
        fnAjaxRequest(API_BASE_URL + 'contentaction.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: postData
        }, onSuccess, onError);
        return deferred.promise;
    }

    var _resetBadge = function() {
        var deferred = Q.defer();

        function onSuccess() {
            setJsonData('getContent', '{"module":[]}');
            var data = getJsonData('getContent');
            deferred.resolve(data);
        }
        /* NEED TO SET THE POST DATA */
        onSuccess();
        return deferred.promise;
    }

    var _makeCustomHomePopup = function() {
        //Hide the topbar
        $('#dvModalHeader').addClass('hide');

        //Increase the width
        $('#dvWebView').find('.aw-modal').addClass('custom-home');

        //Set body
        $('body').addClass('is-customhome');
    };

    //Validate that the quiz/survey is filled
    var _fnValidateQuestionnaire = function() {

        var isValid = true;
        var objOptSelected = [];
        $('#dr-quiz-qa-section').find('.js-quiz-ques').each(function(index, value) {
            var $thisQ = $(value);
            var thisQType = $thisQ.data('qType');

            if (thisQType === 'MCQ' || thisQType === 'MRQ') {
                var thisSelectedOpt = $thisQ.find('.js-quiz-opt.selected').length;
                if (thisSelectedOpt === 0) {
                    //Oopsie!
                    //var $currQ = $('#dr-quiz-qa-section').find('.js-quiz-ques:last-child');

                    //$thisQ.addClass('active').addClass('quiz-ques-error');
                    //$currQ.removeClass('active');

                    //_switchDivsAnimated($currQ, $thisQ, 'ltr');
                    //$('#btnNextQuestion').parent().removeClass('hide');
                    ////Hide submit wala button
                    //$('#btnSubmitQuiz').addClass('hide');
                    //if (index === 0) {
                    //    $('#btnPrevQuestion').parent().addClass('hide');
                    //}

                    //isValid = false;
                    //return false;

                    var objThisOpt = {};
                    objThisOpt.o = [];
                    objThisOpt.qtype = thisQType;

                    objOptSelected.push(objThisOpt);
                } else {
                    var objThisOpt = {};
                    objThisOpt.o = [];
                    objThisOpt.qtype = thisQType;
                    //Add to that
                    $thisQ.find('.js-quiz-opt').each(function(index, value) {
                        var $this = $(value);
                        if ($this.hasClass('selected')) {
                            objThisOpt.o.push(index + 1 + '');
                        }
                    });
                    objOptSelected.push(objThisOpt);
                    //$thisQ.removeClass('quiz-ques-error');
                }
            } else if (thisQType === 'Sub') {
                var thisQVal = $.trim($thisQ.find('.js-ques-text').val());

                var objThisOpt = {};
                objThisOpt.o = [thisQVal];
                objThisOpt.qtype = thisQType;

                objOptSelected.push(objThisOpt);
            } else if (thisQType === 'Rating') {
                var thisQVal = $thisQ.find('.star-rating').find('input:checked').val();

                var objThisOpt = {};
                objThisOpt.o = [thisQVal];
                objThisOpt.qtype = thisQType;

                objOptSelected.push(objThisOpt);
            }
        });

        return objOptSelected;
    }

    var objPPTSeen = {
        cid: 0,
        slide: []
    };

    var _pptAnalysis = function() {
        var postData = {
            type: 'presentationWatched',
            data: {
                uid: user_id,
                cid: objPPTSeen.cid,
                time_spent: 0,
                slide_seen: objPPTSeen.slide
            }
        };
        var onSuccess = function() {};
        fnAjaxRequest(API_BASE_URL + 'contentaccessed.aspx', 'POST', {
            Authorization: 'Bearer ' + base64String
        }, {
            abc: JSON.stringify(postData)
        }, onSuccess, onError);
    }

    var _fnAppendUserId = function(webUrl, notiId) {
        // var sso = localStorage.getItem('sso');
        var appUrl = '';
        if (sso) {
            var objSSO = JSON.parse(sso);
            if (webUrl.indexOf('?') > -1) {
                //QString exists
                appUrl = webUrl + '&dm_eid=' + encodeURIComponent(objSSO.uid);
            } else {
                appUrl = webUrl + '?dm_eid=' + encodeURIComponent(objSSO.uid);
            }
        } else {
            if (webUrl.indexOf('?') > -1) {
                //QString exists
                appUrl = webUrl + '&dm_uid=' + user_id;
            } else {
                appUrl = webUrl + '?dm_uid=' + user_id;
            }
        }

        //append noti_id if any
        if (notiId) {
            appUrl = appUrl + '&dm_noti_id=' + notiId;
        }

        return appUrl;
    }

    //fn: add events
    var _onEvent = function() {
    }

    var _switchDivsAnimated = function($dv1, $dv2, dir) {
    };

    var _fnGetCloseMsg = function(contType) {
        var msg = "Are you sure you want to exit";
        switch (contType) {
            case "v":
                {
                    return msg + '?';
                }
            case "audio":
                {
                    return msg + '?';
                }
            case "text":
                {
                    return msg + '?';
                }
            case "pdf":
                {
                    return msg + '?';
                }
            case "n":
                {
                    return msg + '?';
                }
            case "article":
                {
                    return msg + '?';
                }
            case "p":
                {
                    return msg + '?';
                }
            case "q":
                {
                    return msg + ' without submitting your answers?';
                }
            case "s":
                {
                    return msg + ' without submitting your responses?';
                }
            case "embed":
                {
                    return msg + '?';
                }
            case "ig":
                {
                    return msg + '?';
                }
            case "form":
                {
                    return msg + '?';
                }
        }
    }

    var _fnActualCloseModal = function() {
    

    };

    var _fnContentAnalysis = function() {};

    var _fnCloseAwesomeModal = function(byPass) {
    };

    var $modal, $overlay;

    var _awesomeModal = function(yoCustomHome) {
    };

    //loading inbox by default //
    var _defaultview = function() {

        //$("#inbox").trigger('click');

    }

    var _fnApplyAppMeta = function() {
        // var objAppMeta = JSON.parse(localStorage.getItem('appMeta'));
        var objAppMeta = getJsonData('appMeta');
        var imgsrc = objAppMeta.top_bar_icon.img_xhdpi;
        var appName = objAppMeta.top_bar_text;
    }

    var _initPlugins = function() {
        //Textarea autoresize
        //$('textarea.auto-size').textareaAutoSize();
    };

    var _initStore = function() {
        storeUser = new Lawnchair({
            name: 'users',
            record: 'user'
        });

        storeNoti = new Lawnchair({
            name: 'notifications',
            record: 'notification'
        });

        storePlugin = new Lawnchair({
            name: 'apps',
            record: 'app'
        });
    };

    var _getContentAPI = function() {
        var deferred = Q.defer();
        var allJsonKeys = getAllJsonKeys();
        var getContent = "getContent";
        var postData = JSON.stringify({
            uid: user_id
        });

    };

    var _fnLoadContent = function(cId, cType) {

        //var cType = $(this).data('type');
        //var cId = $(this).data('cid');
    };

    var _fnLoadIcon = function(cId, cType, folderId) {
    };

    var _fnLoadCategory = function(cId, folderId) {
        //1open popup
        
    };

    var startLoadingPageUI = function() {
     
    }

    var stopLoadingPageUI = function() {
     
    }

    return {
        init: function() {

            //Intialize DB Store
            _initStore();
            authToken();
            _initUser();
            _initPlugins();

            //Show loading.

            //startPageBlock();
            _onEvent();

            /* GetContent.aspx */

                //Send event to cordova webview for custom home to consume
                if (objCordovaWebView) {
                    objCordovaWebView.fireDocumentEvent('dronahq.app.getbadge', unreadCount);
                    objCordovaWebView.fireDocumentEvent('dronahq.app.showflash', firstmodule);
                }
            /* in background we need to check if this account has a custom homescreen or not.*/
        },

        closeAwesomeModal: function() {
            _fnActualCloseModal();
        },

        loadInbox: function() {
            $("#inbox").trigger('click');
        },

        loadContent: function(destId, destType) {
            _fnLoadContent(destId, destType);
        },

        logout: function() {
            _logout(true);
        },

        loadIcon: function(destId, destType, folderId) {
            _fnLoadIcon(destId, destType, folderId);
        },

        loadCategory: function(destId, folderId) {
            _fnLoadCategory(destId, folderId);
        },

        fetchKnowledgeBase: function() {
            return _loadAppList();
        },

        fetchInbox: function(_maxInboxId, _maxInboxResult, searchText, filterType) {
            return _loadInboxData(_maxInboxId, _maxInboxResult, searchText, filterType);
        },

        getCommentList: function(contentId) {
            return _loadCommentlist(contentId);
        },

        setLike: function(contentId, likeStatus) {
            return _addlike(contentId, likeStatus);
        },

        getLikeList: function(contentId) {
            return _loadlikelist(contentId);
        },

        setBookmark: function(contentId, bkmrkStatus) {
            return _addbkmrk(contentId, bkmrkStatus);
        },

        getAllBookmarks: function() {
            return _getbkmrks();
        },

        addComment: function(contentId, userComment) {
            return _addcomment(contentId, userComment);
        },

        deleteInboxEntry: function(inboxId) {
            return _delInboxEntry(inboxId);
        },

        setAppRating: function(appRating) {
            return _fnSetRating(appRating);
        },

        handleMedia: function(mediaUrl, mediaType) {
            return _handleTheMedia(mediaUrl, mediaType);
        },
        resetBadge: function() {
            return _resetBadge();
        }

    }
};


document.addEventListener('DOMContentLoaded', function(){ 
    window.objDronaHQ = new DronaAppLanding();
    window.objDronaHQ.init();
}, false);