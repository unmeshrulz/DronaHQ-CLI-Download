const electron = require("electron");
const {
  app,
  BrowserWindow,
  Menu,
  Tray,
  ipcMain
} = electron;
const path = require('path');
const url = require('url');


let theMinimumWidth = 800;
let theMinimumHeight = 600;

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.

let win

electron.app.on('browser-window-created', function (e, window) {
  window.setMenu(null);
  window.setTitle("DronaHQ");
});

function createWindow() {
  // Create the browser window.
  win = new BrowserWindow({
    webPreferences: {
      nodeIntegration: true,
     // preload: path.join(__dirname, 'preload.js')
    },
    minWidth: theMinimumWidth,
    minHeight: theMinimumHeight,
    backgroundColor: '#ffffff',

  })
  // win.setMenu(null)
  // and load the index.html of the app. 
  let pathuser = 'index.html';

  win.loadURL(url.format({
    pathname: path.join(__dirname, pathuser),
    protocol: 'file:',
    slashes: true
  }), {
      userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Electron/1.4.13 Safari/537.36 DronaHQ;"
    })

  // Open the DevTools.
  win.webContents.openDevTools();
  //  win.webContents.isOffscreen()
  // Emitted when the window is closed.

  win.maximize();

  var contextMenu = Menu.buildFromTemplate([{

  }
  ])


  win.on('close', function (event) {
    app.exit();
  });

  win.on('closed', function () {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null
  })
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.4

app.on('ready', createWindow, () => {
  win = new BrowserWindow();
  win.setMenu(null);
  win.webContents.on('crashed', function () {
    win.reload();
  });
  // Quit when all windows are closed.

  app.on('window-all-closed', () => {
    // On macOS it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (win === null) {
      createWindow();
    }
  });

  /* CODE TO AUTOSTART ELECTRON AT STARTUP MWAHAHAHA 
     BUT WILL ONLY WORK WITH WINDWOS AND MAC 
  */

  app.setLoginItemSettings({
    openAtLogin: true
  });
});
// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.